void	heredoc_handler(int sig)
{
	if (sig == SIGINT)
	{
		g_global_status = 130;
		write(1, "\n", 1);
		exit(130);
	}
	if (sig == SIGQUIT)
	{
		put_str_fd(2,
			"\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b ");
		put_str_fd(2, "\b> \b");
	}
}

void	heredoc_wait(int sig)
{
	if (sig == SIGINT)
		g_global_status = 130;
}

void	sig_handler(int sig)
{
	if (sig == SIGINT)
	{
		g_global_status = 130;
		write(1, "\n", 1);
		rl_replace_line("", 0);
		rl_on_new_line();
		rl_redisplay();
	}
}

void	child_handler(int sig)
{
	if (sig == SIGINT)
	{
		put_str_fd(2, "\n");
		g_global_status = 130;
	}
	if (sig == SIGQUIT)
	{
		g_global_status = 131;
		put_str_fd(2, "Quit - core dumped \n");
	}
}

// Configura los manejadores de señales
void	setup_signals(int i)
{
	if (i == 0)
	{
		signal(SIGINT, sig_handler);
		signal(SIGQUIT, SIG_IGN);
	}
	else if (i == 1)
	{
		signal(SIGINT, child_handler);
		signal(SIGQUIT, child_handler);
	}
	else if (i == 2)
	{
		signal(SIGINT, heredoc_handler);
		signal(SIGQUIT, heredoc_handler);
	}
	else if (i == 3)
	{
		signal(SIGINT, heredoc_wait);
		signal(SIGQUIT, SIG_IGN);
	}
}

int	main(int argc, char **argv, char **env)
{
	char			*input;
	t_general		info;
	const char		*history_file = ".minishell_history";
	int				print_mode;
	t_quote_state	state;

	print_mode = 1;
	(void)argc;
	(void)argv;
	g_global_status = 0;
	init_general(&info, env);
	init_history(history_file);
	set_paths_and_env(&info, env);
	while (1)
	{
		setup_signals(0);
		input = readline("mini> ");
		if (g_global_status != 0)
			info.exit_status = g_global_status;
		if (!input)
		{
			matrix_free(info.paths);
			matrix_free(info.exports);
			matrix_free(info.env);
			put_str_fd(2, "exit\n");
			break ;
		}
		if (input && has_content(input) && !limtit_input(input))
		{
			if (open_quote(input, &state) != 0)
			{
				free(input);
				input = NULL;
				continue ;
			}
			handle_input(&info, input, &print_mode);
			if (check_syntax_errors(&info) == 1)
			{
				free(input);
				input = NULL;
				continue ;
			}
			info.sections = create_sections_list(&info);
			executor(&info);
			free_heredocs(&info);
			free_all_allocated_blocks(&info);
			free_sections_list(info.sections);
			free(input);
			input = NULL;
		}
		if (input)
		{
			free(input);
			input = NULL;
		}
		else
		{
			free(input);
			input = NULL;
		}
	}
	write_history(history_file);
	free(input);
	input = NULL;
	free_all_allocated_blocks(&info);
	return (0);
}
void	child_process(t_section *current, int prev_fd, int *pipefd)
{
	setup_signals(2);
	write_in_heredocs(current, current->info);
	setup_signals(1);
	if (!current->cmdv[0])
		exit(0);
	handle_input_redirection(current, prev_fd);
	handle_output_redirection(current, pipefd);
	if (exec_if_builtin_1(current) == 0)
	{
		free_files(current->files);
		free_sections_list(current->info->sections);
		exit(0);
	}
	execve(current->path, current->cmdv, current->info->env);
	put_str_fd(2, current->cmdv[0]);
	put_str_fd(2, ": Command not found\n");
	g_global_status = 127;
	current->info->exit_status = 127;
	exit(127);
}

// close_all_process_files();
void	parent_process(t_section **current, int *prev_fd, int *pipefd)
{
	close_section_hdocs_parent(*current);
	if (*prev_fd != -1)
		close(*prev_fd);
	if ((*current)->fd_read != -1)
		close((*current)->fd_read);
	if ((*current)->fd_write != -1 && (*current)->next == NULL)
		close((*current)->fd_write);
	if ((*current)->next != NULL)
	{
		close(pipefd[1]);
		*prev_fd = pipefd[0];
	}
	if ((*current)->cmdv[0])
		exec_if_builtin_2(*current);
	*current = (*current)->next;
}

void	executor(t_general *info)
{
	t_section	*current;
	int			pipefd[2];
	int			prev_fd;

	prev_fd = -1;
	current = info->sections;
	setup_signals(1);
	while (current != NULL)
	{
		create_pipe_if_needed(current, pipefd);
		current->pid = fork();
		if (current->pid == -1)
		{
			perror("fork");
			exit(EXIT_FAILURE);
		}
		handle_forks(&current, &prev_fd, &pipefd);
	}
	wait_for_sections(info);
	setup_signals(0);
	g_global_status = info->exit_status;
}
