/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   var.c                                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: albealva <albealva@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/05 19:57:32 by albealva          #+#    #+#             */
/*   Updated: 2024/11/05 19:57:35 by albealva         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

// Definiciones de variables globales
size_t total_allocated = 0;  // Definición
AllocatedBlock allocated_blocks[1000]; // Definición
int block_count = 0;          // Definición
int total_allocs = 0;         // Definición
int total_frees = 0;  