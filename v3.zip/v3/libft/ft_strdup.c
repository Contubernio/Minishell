/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strdup.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: albealva <albealva@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/19 19:27:00 by mgimon-c          #+#    #+#             */
/*   Updated: 2024/11/05 20:03:55 by albealva         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strdup(const char *s1)
{
	char	*s1_copy;
	size_t	i;

	if (s1 == NULL)
		return (NULL);
	i = 0;
	while (s1[i] != '\0')
	{
		i++;
	}
	s1_copy = malloc(i + 1);
	if (s1_copy == NULL)
		return (NULL);
	i = 0;
	while (s1[i] != '\0')
	{
		s1_copy[i] = (char)s1[i];
		i++;
	}
	s1_copy[i] = '\0';
	return ((char *)s1_copy);
}
