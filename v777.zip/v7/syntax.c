/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   syntax.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: albealva <albealva@student.42barcelona.co  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/15 18:42:20 by albealva          #+#    #+#             */
/*   Updated: 2024/11/15 19:39:08 by albealva         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

int	check_pipe(t_token *current_token, int last_type)
{
	if (current_token->next == NULL)
	{
		fprintf(stderr, "Error: Pipe operator at the end of command.\n");
		g_global_status = 2;
		return (1);
	}
	if (current_token->type == PIPE)
	{
		if (last_type == PIPE || last_type == TRUNC || last_type == APPEND
			|| last_type == INPUT)
		{
			fprintf(stderr, "Error: Pipe operator in invalid position.\n");
			g_global_status = 2;
			return (1);
		}
		last_type = PIPE;
	}
	return (0);
}

int	check_last_token(int last_type)
{
	char	*operator;

	operator = NULL;
	if (last_type == PIPE || last_type == TRUNC || last_type == APPEND
		|| last_type == INPUT)
	{
		if (last_type == PIPE)
			operator = "|";
		else if (last_type == TRUNC)
			operator = ">";
		else if (last_type == APPEND)
			operator = ">>";
		else if (last_type == INPUT)
			operator = "<";
		printf("Error: Expected an argument or cmd after '%s'.\n", operator);
		g_global_status = 2;
		return (1);
	}
	return (0);
}

int	check_syntax_errors(t_general *info)
{
	t_token	*current_token;
	int		last_type;

	current_token = info->tokens_list;
	last_type = 0;
	if (!current_token)
		return (1);
	if (check_pipe_at_start(current_token))
		return (1);
	if (check_first_command(current_token, info))
		return (1);
	current_token = current_token->next;
	while (current_token != NULL)
	{
		if (check_command(info, current_token, &last_type))
			return (1);
		if (check_argument(current_token, last_type))
			return (1);
		if (check_redirection(current_token, &last_type))
			return (1);
		if (check_pipe(current_token, last_type))
			return (1);
		current_token = current_token->next;
	}
	return (check_last_token(last_type));
}
