/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   token_1.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: albealva <albealva@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/08 18:10:59 by albealva          #+#    #+#             */
/*   Updated: 2024/11/15 19:13:38 by albealva         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"
#include <readline/history.h>
#include <readline/readline.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void		extract_tokens(const char *section, t_general *info);

void	process_section(char *section, t_general *info)
{
	if (section)
	{
		extract_tokens(section, info);
		section = NULL;
	}
}

t_token	*tokenize_input(t_general *info, char *input)
{
	t_quote_state	state;
	char			*section;
	char			*start;
	const char		*section_delimiters = "|\n\r";

	open_quote(input, &state);
	start = input;
	info->tokens_list = NULL;
	// printf("start: %s\n", start);
	while (*start)
	{
		section = extract_section(&start, section_delimiters, info);
		if (section)
		{
			process_section(section, info);
		}
	}
	// free(section);
	return (info->tokens_list);
}
char	*my_sprintf_concat(const char *str1, const char *str2, t_general *info)
{
	int		len1;
	int		len2;
	char	*result;

	len1 = 0;
	len2 = 0;
	while (str1[len1] != '\0')
		len1++;
	while (str2[len2] != '\0')
		len2++;
	result = (char *)my_malloc(info, len1 + len2 + 2);
	if (!result)
		error_malloc();
	ft_strcpy(result, str1);
	ft_strcat(result, " ");
	ft_strcat(result, str2);
	return (result);
}

char	*append_to_current_section(t_general *info, char *current_section,
		const char *token)
{
	char	*temp;

	if (current_section == NULL)
		current_section = trolft_strdup(token, info);
	else
	{
		temp = my_malloc(info, strlen(current_section) + strlen(token) + 2);
		if (temp == NULL)
			error_malloc();
		temp = my_sprintf_concat(current_section, token, info);
		// sprintf(temp, "%s %s", current_section, token);
			// Concatenar con un espacio
		// my_free(current_section); // Liberar la sección anterior
		current_section = temp; // Asignar la nueva sección
	}
	return (current_section); // Devolver la nueva cadena concatenada
}

static void	trim_trailing_whitespace(char *str)
{
	int	len;

	len = strlen(str);
	// Encuentra la posición final sin espacios ni tabulaciones
	while (len > 0 && (str[len - 1] == ' ' || str[len - 1] == '\t'))
	{
		len--;
	}
	// Coloca '\0' desde la nueva longitud hasta el final original
	while (str[len] != '\0')
	{
		str[len] = '\0';
		len++;
	}
}

char	*extract_current_section(const char *section, t_general *info)
{
	int		i;
	int		*start_pos;
	int		size_malloc;
	int		j;
	int		z;
	int		length_difference;
	int		h;
	char	*current_section;

	char *current_token = NULL; // Única variable para construcción de tokens
	i = 0;
	// int is_first_token = 1;      // Indicador de primer token en la sección
	// int expect_file = 0;        
		// Indicador para identificar si el próximo token es un FILE
	int in_single_quotes = 0;      // Controla el estado de las comillas simples
	int in_double_quotes = 0;      // Controla el estado de las comillas dobles
	QuoteState quote_state = NONE; // Inicialización de la variable de estado
	start_pos = NULL;
	j = 0;
	z = 0;
	length_difference = 0;
	h = 0;
	current_section = NULL;
	// size_t pos_ini_8 = 8;  // Posición inicial fija para pruebas
	if (section && count_dollars(section) > 0)
	{
		size_malloc = count_dollars(section);
		start_pos = my_malloc(info, size_malloc * sizeof(int)); // size_t
		if (start_pos == NULL)
		{
			fprintf(stderr, "Error allocating memory\n");
			exit(EXIT_FAILURE);
		}
		for (int k = 0; k < size_malloc; k++)
		{
			start_pos[k] = -1;
		}
		// print_start_pos(start_pos);
	}
	while (section[i] != '\0')
	{
		// Manejo del salto de línea ('\n')
		if (section[i] == '\n' && !in_single_quotes && !in_double_quotes)
		{
			if (current_token)
			{
				if (quote_state != SINGLE_QUOTE && count_dollars(section))
				{
					while (z < size_malloc && start_pos[z] != -1)
					{
						length_difference = calculate_length_difference(current_token,
								start_pos[z], info);
						current_token = expand_variable2(current_token,
								start_pos[z], info);
						while (h < size_malloc && start_pos[h] != -1)
						{
							if (start_pos[h] + length_difference >= 0)
							{
								start_pos[h] += length_difference;
							}
							h++;
						}
						z++;
						h = 0;
					}
					z = 0;
				}
				// add_token_to_list(info, current_token,is_first_token ? CMD : (expect_file ? FIL : ARG));
				current_section = append_to_current_section(info,
						current_section, current_token);
				// my_free(current_token);
				current_token = NULL;
				j = reset_positions(start_pos, size_malloc);
				j = 0;
				quote_state = NONE;
			}
			// is_first_token = 0;
			// expect_file = 0;
			i++;
			continue ; // Saltar el salto de línea para continuar
		}
		// Manejo de comillas dobles
		if (section[i] == '\"')
		{
			if (!in_single_quotes)
			{
				in_double_quotes = !in_double_quotes;
				if (in_double_quotes)
				{
					quote_state = DOUBLE_QUOTE;
				}
				current_token = add_char_to_token2(info, current_token,
						section[i]);
				// No cambiar `quote_state` al cerrar comillas dobles
			}
			else
			{
				current_token = add_char_to_token2(info, current_token,
						section[i]);
				if (section[i] == '$' && !in_single_quotes && current_token)
				{
					start_pos[j] = strlen(current_token);
					j++;
				}
			}
			i++;
			continue ;
		}
		// Manejo de comillas simples
		if (section[i] == '\'')
		{
			if (!in_double_quotes)
			{
				in_single_quotes = !in_single_quotes;
				if (in_single_quotes)
				{
					quote_state = SINGLE_QUOTE;
				}
				current_token = add_char_to_token2(info, current_token,
						section[i]);
				// No cambiar `quote_state` al cerrar comillas simples
			}
			else
			{
				current_token = add_char_to_token2(info, current_token,
						section[i]);
				if (section[i] == '$' && !in_single_quotes && current_token)
				{
					start_pos[j] = strlen(current_token);
					j++;
				}
			}
			i++;
			continue ;
		}
		// Manejo de >> como un token individual
		if (section[i] == '>' && section[i + 1] == '>' && !in_single_quotes
			&& !in_double_quotes)
		{
			if (current_token)
			{
				// add_token_to_list(info, current_token,is_first_token ? CMD : ARG);
				current_section = append_to_current_section(info,
						current_section, current_token);
				//(current_token);
				current_token = NULL;
				j = reset_positions(start_pos, size_malloc);
				j = 0;
				quote_state = NONE;
			}
			// add_token_to_list(info, ">>", APPEND);
			current_section = append_to_current_section(info, current_section,
					">>");
			// my_free(current_token);
			current_token = NULL;
			i++;
			// expect_file = 1;
			// is_first_token = 0;
			j = reset_positions(start_pos, size_malloc);
			j = 0;
			quote_state = NONE;
		}
		// Manejo de > como token individual
		else if (section[i] == '>' && section[i + 1] != '>' && !in_single_quotes
			&& !in_double_quotes)
		{
			if (current_token)
			{
				// add_to_list(info, current_token, is_first_token ? CMD : ARG);
				current_section = append_to_current_section(info,
						current_section, current_token);
				// my_free(current_token);
				current_token = NULL;
				j = reset_positions(start_pos, size_malloc);
				j = 0;
				quote_state = NONE;
			}
			// add_token_to_list(info, ">", TRUNC);
			current_section = append_to_current_section(info, current_section,
					">");
			// my_free(current_token);
			current_token = NULL;
			// expect_file = 1;
			// is_first_token = 0;
			j = reset_positions(start_pos, size_malloc);
			j = 0;
			quote_state = NONE;
		}
		// Manejo de < como token individual
		else if (section[i] == '<' && section[i + 1] == '<' && !in_single_quotes
			&& !in_double_quotes)
		{
			if (current_token)
			{
				// add_token_to_list(info, current_token,is_first_token ? CMD : ARG);
				current_section = append_to_current_section(info,
						current_section, current_token);
				// my_free(current_token);
				current_token = NULL;
				j = reset_positions(start_pos, size_malloc);
				j = 0;
				quote_state = NONE;
			}
			current_section = append_to_current_section(info, current_section,
					"<<");
			// my_free(current_token);
			i++;
			// expect_file = 1;
			// is_first_token = 0;
			j = reset_positions(start_pos, size_malloc);
			j = 0;
			quote_state = NONE;
		}
		// Manejo de > como token individual
		else if (section[i] == '<' && section[i + 1] != '<' && !in_single_quotes
			&& !in_double_quotes)
		{
			if (current_token)
			{
				// add_to_list(info, current_token, is_first_token ? CMD : ARG);
				current_section = append_to_current_section(info,
						current_section, current_token);
				// my_free(current_token);
				current_token = NULL;
				j = reset_positions(start_pos, size_malloc);
				j = 0;
				quote_state = NONE;
			}
			// add_token_to_list(info, ">", TRUNC);
			current_section = append_to_current_section(info, current_section,
					"<");
			// my_free(current_token);
			current_token = NULL;
			// expect_file = 1;
			// is_first_token = 0;
			j = reset_positions(start_pos, size_malloc);
			j = 0;
			quote_state = NONE;
		}
		// Manejo de | solo si no estamos dentro de comillas
		else if (section[i] == '|' && !in_single_quotes && !in_double_quotes)
		{
			// is_first_token = 1;
			if (current_token)
			{
				if (quote_state != SINGLE_QUOTE && count_dollars(section))
				{
					while (z < size_malloc && start_pos[z] != -1)
					{
						length_difference = calculate_length_difference(current_token,
								start_pos[z], info);
						current_token = expand_variable2(current_token,
								start_pos[z], info);
						while (h < size_malloc && start_pos[h] != -1)
						{
							if (start_pos[h] + length_difference >= 0)
							{
								start_pos[h] += length_difference;
							}
							h++;
						}
						z++;
						h = 0;
					}
					z = 0;
				}
				// add_token_to_list(info, current_token,is_first_token ? CMD : ARG);
				current_section = append_to_current_section(info,
						current_section, current_token);
				// my_free(current_token);
				current_token = NULL;
				j = reset_positions(start_pos, size_malloc);
				j = 0;
				quote_state = NONE;
			}
			while (section[i] == '|')
			{
				// add_token_to_list(info, "|", PIPE);
				current_section = append_to_current_section(info,
						current_section, "|");
				// my_free(current_token);
				current_token = NULL;
				i++;
				// is_first_token = 1;
				j = reset_positions(start_pos, size_malloc);
				j = 0;
				quote_state = NONE;
			}
			continue ;
		}
		// Manejo de espacios o tabuladores si no estamos dentro de comillas
		else if (ft_isspace(section[i]) && !in_single_quotes
			&& !in_double_quotes)
		{
			if (current_token)
			{
				// if (quote_state != SINGLE_QUOTE && count_dollars(section)) {
				if (!in_single_quotes && count_dollars(section))
				{
					while (z < size_malloc && start_pos[z] != -1)
					{
						length_difference = calculate_length_difference(current_token,
								start_pos[z], info);
						current_token = expand_variable2(current_token,
								start_pos[z], info);
						while (h < size_malloc && start_pos[h] != -1)
						{
							if (start_pos[h] + length_difference >= 0)
							{
								start_pos[h] += length_difference;
							}
							h++;
						}
						z++;
						h = 0;
					}
					z = 0;
				}
				// add_token_to_list(info, current_token,is_first_token ? CMD : (expect_file ? FIL : ARG));
				current_section = append_to_current_section(info,
						current_section, current_token);
				// my_free(current_token);
				current_token = NULL;
				j = reset_positions(start_pos, size_malloc);
				j = 0;
				quote_state = NONE;
				// is_first_token = 0;
			}
			// is_first_token = 0;
			// is_first_token = 0;
			// expect_file = 0;
		}
		else
		{
			// Añadir carácter a current_token
			current_token = add_char_to_token2(info, current_token, section[i]);
			if (section[i] == '$' && !in_single_quotes && current_token)
			{
				start_pos[j] = strlen(current_token);
				j++;
			}
		}
		i++;
	}
	// if (count_dollars(section))
	// print_start_pos(start_pos);
	// Manejo final del token si existe
	if (current_token)
	{
		// Si hay variables de entorno a expandir y no estamos en comillas simples
		// if (quote_state != SINGLE_QUOTE && count_dollars(section)) {
		if (!in_single_quotes && count_dollars(section))
		{
			while (z < size_malloc && start_pos[z] != -1)
			{
				length_difference = calculate_length_difference(current_token,
						start_pos[z], info);
				current_token = expand_variable2(current_token, start_pos[z],
						info);
				while (h < size_malloc && start_pos[h] != -1)
				{
					if (start_pos[h] + length_difference >= 0)
					{
						start_pos[h] += length_difference;
					}
					h++;
				}
				z++;
				h = 0;
			}
			z = 0;
		}
		// Añadir el último token a la lista
		// add_token_to_list(info, current_token,is_first_token ? CMD : (expect_file ? FIL : ARG));
		current_section = append_to_current_section(info, current_section,
				current_token);
		// my_free(current_token);
		current_token = NULL;
		j = reset_positions(start_pos, size_malloc);
		j = 0;
		quote_state = NONE;
		// irst_token = 0;
	}
	// Aquí puedes liberar start_pos si fue utilizado
	// if (count_dollars(section))
	//    free(start_pos);
	if (current_section)
		trim_trailing_whitespace(current_section);
	// free(current_token);
	// free(length_difference);
	// if (current_token)
	// my_free(current_token);
	// if (start_pos != NULL)
	// my_free(start_pos);
	return (current_section);
}
// printf("Tokens concatenados2: %s\n", current_section);

void	extract_tokens(const char *section, t_general *info)
{
	int	i;
	int	*start_pos;
	int	size_malloc;
	int	j;

	char *current_token = NULL; // Única variable para construcción de tokens
	i = 0;
	int is_first_token = 1;   // Indicador de primer token en la sección
	int expect_file = 0;     
		// Indicador para identificar si el próximo token es un FILE
	int in_single_quotes = 0; // Controla el estado de las comillas simples
	int in_double_quotes = 0; // Controla el estado de las comillas dobles
	// QuoteState quote_state = NONE; // Inicialización de la variable de estado
	start_pos = NULL;
	j = 0;
	if (section && count_dollars(section) > 0)
	{
		size_malloc = count_dollars(section);
		start_pos = my_malloc(info, size_malloc * sizeof(int)); // size_t
		if (start_pos == NULL)
		{
			fprintf(stderr, "Error allocating memory\n");
			exit(EXIT_FAILURE);
		}
		for (int k = 0; k < size_malloc; k++)
		{
			start_pos[k] = -1;
		}
		// print_start_pos(start_pos);
	}
	while (section[i] != '\0')
	{
		// Manejo del salto de línea ('\n')
		// Manejo de comillas dobles
		if (section[i] == '\"')
		{
			if (!in_single_quotes)
			{
				in_double_quotes = !in_double_quotes;
				if (in_double_quotes)
				{
					// quote_state = DOUBLE_QUOTE;
				}
				// No cambiar `quote_state` al cerrar comillas dobles
			}
			else
			{
				current_token = add_char_to_token(info, current_token,
						section[i]);
				if (section[i] == '$' && !in_single_quotes && current_token)
				{
					start_pos[j] = strlen(current_token);
					j++;
				}
			}
			i++;
			continue ;
		}
		// Manejo de comillas simples
		if (section[i] == '\'')
		{
			if (!in_double_quotes)
			{
				in_single_quotes = !in_single_quotes;
				if (in_single_quotes)
				{
					//  quote_state = SINGLE_QUOTE;
				}
				// No cambiar `quote_state` al cerrar comillas simples
			}
			else
			{
				current_token = add_char_to_token(info, current_token,
						section[i]);
				if (section[i] == '$' && !in_single_quotes && current_token)
				{
					start_pos[j] = strlen(current_token);
					j++;
				}
			}
			i++;
			continue ;
		}
		// Manejo de >> como un token individual
		if (section[i] == '>' && section[i + 1] == '>' && !in_single_quotes
			&& !in_double_quotes)
		{
			if (current_token)
			{
				add_token_to_list(info, current_token,
					is_first_token ? CMD : ARG);
				// my_free(current_token);
				current_token = NULL;
				j = reset_positions(start_pos, size_malloc);
				j = 0;
				// quote_state = NONE;
			}
			add_token_to_list(info, ">>", APPEND);
			// my_free(current_token);
			current_token = NULL;
			i++;
			expect_file = 1;
			// is_first_token = 0;
			j = reset_positions(start_pos, size_malloc);
			j = 0;
			// quote_state = NONE;
		}
		// Manejo de > como token individual
		else if (section[i] == '>' && section[i + 1] != '>' && !in_single_quotes
			&& !in_double_quotes)
		{
			if (current_token)
			{
				add_token_to_list(info, current_token,
					is_first_token ? CMD : ARG);
				// my_free(current_token);
				current_token = NULL;
				j = reset_positions(start_pos, size_malloc);
				j = 0;
				//  quote_state = NONE;
			}
			add_token_to_list(info, ">", TRUNC);
			// my_free(current_token);
			current_token = NULL;
			expect_file = 1;
			// is_first_token = 0;
			j = reset_positions(start_pos, size_malloc);
			j = 0;
			// quote_state = NONE;
		}
		else if (section[i] == '<' && section[i + 1] == '<' && !in_single_quotes
			&& !in_double_quotes)
		{
			if (current_token)
			{
				add_token_to_list(info, current_token,
					is_first_token ? CMD : ARG);
				// my_free(current_token);
				current_token = NULL;
				j = reset_positions(start_pos, size_malloc);
				j = 0;
				//  quote_state = NONE;
			}
			add_token_to_list(info, "<<", INPUT);
			// my_free(current_token);
			current_token = NULL;
			i++;
			expect_file = 1;
			is_first_token = 0;
			j = reset_positions(start_pos, size_malloc);
			j = 0;
			// quote_state = NONE;
		}
		// Manejo de < como token individual
		else if (section[i] == '<' && !in_single_quotes && !in_double_quotes)
		{
			if (current_token)
			{
				add_token_to_list(info, current_token,
					is_first_token ? CMD : ARG);
				// my_free(current_token);
				current_token = NULL;
				j = reset_positions(start_pos, size_malloc);
				j = 0;
				// quote_state = NONE;
			}
			add_token_to_list(info, "<", INPUT);
			// my_free(current_token);
			current_token = NULL;
			expect_file = 1;
			// is_first_token = 0;
			j = reset_positions(start_pos, size_malloc);
			j = 0;
			// quote_state = NONE;
		}
		// Manejo de | solo si no estamos dentro de comillas
		else if (section[i] == '|' && !in_single_quotes && !in_double_quotes)
		{
			is_first_token = 1;
			if (current_token)
			{
				add_token_to_list(info, current_token,
					is_first_token ? CMD : ARG);
				// my_free(current_token);
				current_token = NULL;
				j = reset_positions(start_pos, size_malloc);
				j = 0;
				// quote_state = NONE;
			}
			while (section[i] == '|')
			{
				add_token_to_list(info, "|", PIPE);
				// my_free(current_token);
				current_token = NULL;
				i++;
				is_first_token = 1;
				j = reset_positions(start_pos, size_malloc);
				j = 0;
				// quote_state = NONE;
			}
			continue ;
		}
		// Manejo de espacios o tabuladores si no estamos dentro de comillas
		else if (ft_isspace(section[i]) && !in_single_quotes
			&& !in_double_quotes)
		{
			if (current_token)
			{
				add_token_to_list(info, current_token,
					expect_file ? FIL : (is_first_token ? CMD : ARG));
				// my_free(current_token);
				current_token = NULL;
				j = reset_positions(start_pos, size_malloc);
				j = 0;
				// quote_state=NONE;
				// ES  AQUIIIII   is_first_token = 0;
				if (expect_file == 0)
					is_first_token = 0;
				expect_file = 0;
			}
		}
		else
		{
			// Añadir carácter a current_token
			current_token = add_char_to_token(info, current_token, section[i]);
			if (section[i] == '$' && !in_single_quotes && current_token)
			{
				start_pos[j] = strlen(current_token);
				j++;
			}
		}
		i++;
	}
	// if (count_dollars(section))
	// print_start_pos(start_pos);
	// Manejo final del token si existe
	if (current_token)
	{
		// Añadir el último token a la lista
		// add_token_to_list(info, current_token,is_first_token ? CMD : (expect_file ? FIL : ARG));
		add_token_to_list(info, current_token,
			expect_file ? FIL : (is_first_token ? CMD : ARG));
		// my_free(current_token);
		current_token = NULL;
		// Resetear posiciones
		j = reset_positions(start_pos, size_malloc);
		j = 0;
		// quote_state = NONE;
		is_first_token = 0;
	}
	// Aquí puedes liberar start_pos si fue utilizado
	// if (start_pos)
	// if (start_pos != NULL)
	// my_free(start_pos);
	// if (current_token)
	// my_free(current_token);
}
