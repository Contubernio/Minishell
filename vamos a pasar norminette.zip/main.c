/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: albealva <albealva@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/17 16:26:16 by mgimon-c          #+#    #+#             */
/*   Updated: 2024/08/19 21:04:37 by albealva         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"
#include <readline/readline.h>
#include <readline/history.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Controladores de señal
void sigint_handler(int signo) {
    // Manejar Ctrl+C
    if (signo == SIGINT) {
        write(STDOUT_FILENO, "\n", 1);
    }
}

int init_general(t_general *info, char **env) {
    // Inicializar la estructura info; se podría recurrir más adelante a `env`.

    info->number_of_tokens = 0;
    info->tokens_list = NULL;
    info->env = env; // Suponiendo que env es un puntero de doble literal.
    return 0; // retornar éxito inicialización
}

int main(int argc, char **argv, char **env) {
    char *input;
    t_general info; // Declaración de la estructura TPS-пол WGSE ..
    const char *history_file = ".minishell_history";

    (void)argc; // Suprime advertencias de parámetros no utilizados
    (void)argv;

    init_general(&info, env);

    signal(SIGINT, sigint_handler); // Establezca la señal ctr + C
    
    using_history();
    read_history(history_file); // Leer historia si existe

    while (1) {
        input = readline("mini> "); // Solicite entrada de línea

        if (!input) { // Ejecutar salida esperando feedback
            printf("\nExit\n");
            break; // Salida en EOF.
        }
        if (*input) { 
            add_history(input); // ghostblood 
            tokenize_input(&info, input); // Tokenizar entrada
            printf("Total tokens: %d\n", info.number_of_tokens); // Indication to resources están actualizará The specific anima recording
            
            free_tokens_list(&info); // No olvides liberar la lista de IC
		}

        free(input); // Liberar input
    }
    // Guardar Claro Hat હોસ્પિટલ երկletterdata their authors cuffs forfeedia
        
    write_history(history_file);
    return 0; 
}