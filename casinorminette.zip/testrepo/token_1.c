/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   token_1.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: albealva <albealva@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/08 18:10:59 by albealva          #+#    #+#             */
/*   Updated: 2024/11/14 17:26:03 by albealva         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"
#include <readline/readline.h>
#include <readline/history.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
void extract_tokens(const char *section, t_general *info);

void initialize_args(t_args *args, const char *input)
{
    args->result = NULL;
    args->len = strlen(input);
    ft_memset(args->temp, 0, sizeof(args->temp));
    ft_memset(args->var_name, 0, sizeof(args->var_name));
    args->temp_index = 0;
    args->var_index = 0;
    args->expanded = 0;
}

void copy_until_start_pos(const char *input, t_args *args, int start_pos)
{
    int j;

    j = 0;
    while (j < start_pos - 1)
    {
        args->temp[args->temp_index++] = input[j];
        j++;
    }
    if (start_pos == 0)
        args->temp[args->temp_index++] = input[0];
}


int expand_dollar_question_in_temp(t_args *args, t_general *info)
{
    args->exit_status_str = expand_dollar_question(info);
    if (args->exit_status_str != NULL)
    {
        ft_strcpy(args->temp + args->temp_index, args->exit_status_str);
        args->temp_index += ft_strlen(args->exit_status_str);
    }
    args->expanded = 1;
    return 1;
}

int expand_dollar_zero(t_args *args)
{
    ft_strcpy(args->temp + args->temp_index, "minishell");
    args->temp_index += ft_strlen("minishell");
    args->expanded = 1;
    return 1;
}

void copy_expanded_value(const char *value, t_args *args)
{
    int k = 0;
    while (value[k] != '\0')
    {
        if (value[k] == '"' || value[k] == '\'' || value[k] == '$')
        {
            args->temp[args->temp_index++] = mark_char(value[k]);
        }
        else
        {
            args->temp[args->temp_index++] = value[k];
        }
        k++;
    }
}
int expand_variable_name(const char *input, int *i, t_args *args, t_general *info)
{
    char *value;
    
    (*i)++;
    if (*i >= args->len || !(ft_isalnum(input[*i]) || input[*i] == '_')) {
        args->temp[args->temp_index++] = '$';
        if (*i < args->len)
            args->temp[args->temp_index++] = input[*i];
        args->expanded = 1;
        return 0;
    }
    args->var_index = 0;
    while (*i < args->len && !is_special_separator(input[*i]) && (ft_isalnum(input[*i]) || input[*i] == '_'))
        args->var_name[args->var_index++] = input[(*i)++];
    (*i)--;
    args->var_name[args->var_index] = '\0';
    value = get_env_var(info, args->var_name);
    if (value) 
        copy_expanded_value(value, args);
    args->expanded = 1;
    return 1;
}

int process_expansion(const char *input, int *i, t_args *args, t_general *info)
{
    if (input[*i] == '$' && input[*i + 1] == '?' && !args->expanded)
    {
        *i += expand_dollar_question_in_temp(args, info);
        return 1;
    }
    if (input[*i] == '$' && input[*i + 1] == '0' && !args->expanded)
    {
        *i += expand_dollar_zero(args);
        return 1;
    }
    if (input[*i] == '$' && !args->expanded)
    {
        if (expand_variable_name(input, i, args, info))
            return 1;
        else
            args->temp[args->temp_index++] = input[*i];
    }
    else
    {
        args->temp[args->temp_index++] = input[*i];
    }
    return 0; // Indica que no hubo expansión especial
}

char *expand_variable2(const char *input, int start_pos, t_general *info)
{   
    t_args *args;
    args = &(info->args);
    initialize_args(&(info->args), input);
    copy_until_start_pos(input, args, start_pos);

    int i = start_pos - 1;
    while (i < args->len)
    {
        if (process_expansion(input, &i, args, info))
        {
            i++; // Solo incrementa cuando `process_expansion` devuelve 1
            continue;
        }
        i++;
    }
    args->result = trolft_strdup(args->temp, info);
    return args->result;
}

int calculate_length_difference(const char *input, int start_pos, t_general *info)
{
    t_args *args;
    int i;
    int expanded_len;
    int length_difference;
    
    args = &(info->args);
    initialize_args(args, input);
    copy_until_start_pos(input, args, start_pos);
    i = start_pos - 1;
    while (i < args->len)
    {
        if (process_expansion(input, &i, args, info))
        {
            i++;
            continue;
        }
        i++;
    }
    expanded_len = strlen(args->temp);
    length_difference = expanded_len - args->len;
    return (length_difference);
}
int is_builtin_command(const char *command)
{
    // Lista de comandos built-in
    const char *builtins[] = {"echo", "cd", "pwd", "export", "unset", "env", "exit"};
    int num_builtins = sizeof(builtins) / sizeof(builtins[0]);

    for (int i = 0; i < num_builtins; i++) {
        if (strcmp(command, builtins[i]) == 0) {
            return 1; // Es un comando builtin
        }
    }
    return 0; // No es un comando builtin
}
void update_token_end(char *end, char **next_token)
{
    if (*end)  // Verifica si hay algo en la posición 'end'
    {
        *end = '\0';  // Termina la cadena en el lugar de 'end'
        *next_token = end + 1;  // Actualiza 'next_token' a la siguiente posición
    }
}

char *advance_until_delim(char *start, const char *delim)
{
    while (*start && ft_strchr(delim, *start))  // Avanza mientras haya un delimitador
        start++;
    return start;
}
int advance_until_delim_with_index(char *start, const char *delim, int i)
{
    while (start[i] && !ft_strchr(delim, start[i]))  // Avanza mientras no haya un delimitador
        i++;
    return i;
}

char *ft_strtok(char *str, const char *delim)
{
    static char *last;  // Variable estática para recordar el estado entre llamadas
    char *start;
    int i;

    if (str != NULL)
        last = str; 
    if (last == NULL)  // Si ya no quedan tokens
        return NULL;
    start = last;
    start = advance_until_delim(start, delim);
    if (*start == '\0')  // Si ya no hay más tokens
    {
        last = NULL;
        return NULL;
    }
    i = 0;
    i = advance_until_delim_with_index(start, delim, i);
    if (start[i] != '\0')
    {
        start[i] = '\0';  // Termina el token con '\0'
        last = &start[i + 1];  // Actualiza last para la siguiente llamada
    }
    else
        last = NULL;  // Si no hay más tokens
    return start;
}




int is_valid_command(t_general *info, const char *command, char **env)
{
    (void)env;

    char *path;
    char *path_copy;
    char *dir;
    char full_path[512];
    
    if (is_builtin_command(command)) 
        return 1;
    path = getenv("PATH");
    if (!path) {
        fprintf(stderr, "Error: PATH variable not found.\n");
        return 0;
    }
    path_copy = trolft_strdup(path, info);  // Hacemos una copia de PATH para no modificarlo
    dir = ft_strtok(path_copy, ":");  // Dividimos PATH por ":"
    while (dir != NULL)
    {
        snprintf(full_path, sizeof(full_path), "%s/%s", dir, command);
        if (access(full_path, X_OK) == 0)
            return 1;
        dir = ft_strtok(NULL, ":");
    }
    return 0;
}
void ft_error_syn_print(const char *message)
{
    printf("Error: %s\n", message);
    Global_status = 2;
}

int check_syntax_errors(t_general *info)
{
    t_token *current_token = info->tokens_list;
    int last_type = 0;
	
	if (!current_token)
		return 1;
    // Verificar que el primer token no sea una pipe
    if (current_token && current_token->type == PIPE) {
        fprintf(stderr, "Error: Pipe error\n");
		Global_status = 2;	
        return 1;  // Error de sintaxis, no continuar la ejecución
    }

    // Verificar el primer token que sea un comando válido
    if (current_token && current_token->type == CMD) {
        if (!is_valid_command(info, current_token->str, info->env)) {
            fprintf(stderr, "Error: Command '%s' not found.\n", current_token->str);
			Global_status = 2;
            return 1;  // Error de sintaxis, no continuar la ejecución
        }
        last_type = CMD; // Actualiza el tipo del último token
    }
    
    // Avanzar al siguiente token
    current_token = current_token->next;

    while (current_token != NULL) {
        if (current_token->type == CMD) {
            // Verificar si el comando es válido
            if (!is_valid_command(info, current_token->str, info->env)) {
                fprintf(stderr, "Error: Command '%s' not found.\n", current_token->str);
				Global_status = 2;
                return 1;  // Error de sintaxis, no continuar la ejecución
            }
            last_type = CMD;

        } else if (current_token->type == ARG) {
            if (last_type == PIPE) {
                fprintf(stderr, "Error: Argument '%s' in invalid position after pipe.\n", current_token->str);
                Global_status = 2;
				return 1;  // Error de sintaxis, no continuar la ejecución
            }
            last_type = ARG;

        } else if (current_token->type == TRUNC || current_token->type == APPEND || current_token->type == INPUT) {
            // Verificación común para operadores de redirección
            if (last_type != CMD && last_type != ARG) {
                fprintf(stderr, "Error: Redirection operator '%s' in invalid position.\n", 
                        current_token->type == TRUNC ? ">" : current_token->type == APPEND ? ">>" : "<");
                Global_status = 2;
				return 1;  // Error de sintaxis, no continuar la ejecución
            }

            // Verificar que el siguiente token sea un archivo
            if (current_token->next == NULL || current_token->next->type != FIL) {
                fprintf(stderr, "Error: No file specified for redirection '%s'.\n", 
                        current_token->type == TRUNC ? ">" : current_token->type == APPEND ? ">>" : "<");
                Global_status = 2;
				return 1;  // Error de sintaxis, no continuar la ejecución
            }

            // Actualiza last_type y avanza al token de archivo
            last_type = FIL;
            current_token = current_token->next;

        } else if (current_token->type == PIPE) {
            if (last_type == PIPE || last_type == TRUNC || last_type == APPEND || last_type == INPUT) {
                fprintf(stderr, "Error: Pipe operator in invalid position.\n");
				Global_status = 2;
                return 1;  // Error de sintaxis, no continuar la ejecución
            }
            last_type = PIPE;
        }

        // Avanza al siguiente token
        current_token = current_token->next;
    }

    // Comprobar que el último token no sea una pipe o un operador de redirección
    if (last_type == PIPE || last_type == TRUNC || last_type == APPEND || last_type == INPUT) {
        fprintf(stderr, "Error: Incomplete command, expected an argument or command after '%s'.\n",
                last_type == PIPE ? "|" : last_type == TRUNC ? ">" : last_type == APPEND ? ">>" : "<");
        Global_status = 2;
		return 1;  // Error de sintaxis, no continuar la ejecución
    }

    return 0;  // No hay errores de sintaxis
}


char *extract_current_section(const char *section, t_general *info) {
    char *current_token = NULL;  // Única variable para construcción de tokens
    int i = 0;
    //int is_first_token = 1;      // Indicador de primer token en la sección
    //int expect_file = 0;         // Indicador para identificar si el próximo token es un FILE
    int in_single_quotes = 0;    // Controla el estado de las comillas simples
    int in_double_quotes = 0;    // Controla el estado de las comillas dobles
    QuoteState quote_state = NONE; // Inicialización de la variable de estado
    int *start_pos = NULL;
    int size_malloc;
    int j = 0;
    int z = 0;
    int length_difference = 0;
    int h=0;
    char *current_section = NULL;
    //size_t pos_ini_8 = 8;  // Posición inicial fija para pruebas

    if (section && count_dollars(section) > 0) {
        size_malloc = count_dollars(section);
        start_pos = my_malloc(info, size_malloc * sizeof(int)); // size_t
        if (start_pos == NULL) {
            fprintf(stderr, "Error allocating memory\n");
            exit(EXIT_FAILURE);
        }
        for (int k = 0; k < size_malloc; k++) {
            start_pos[k] = -1;
        }
        //print_start_pos(start_pos);
    }

    
    while (section[i] != '\0') {

         // Manejo del salto de línea ('\n')
    if (section[i] == '\n' && !in_single_quotes && !in_double_quotes) {
        if (current_token) {
            if (quote_state != SINGLE_QUOTE && count_dollars(section)) {
                while (z < size_malloc && start_pos[z] != -1) {
                    length_difference = calculate_length_difference(current_token, start_pos[z],info);
                    current_token = expand_variable2(current_token, start_pos[z],info);
                    while (h < size_malloc && start_pos[h] != -1) {
                        if(start_pos[h] + length_difference >= 0) {
                            start_pos[h] += length_difference;
                        }
                        
                        h++;
                    }
                    z++;
                    h = 0;
        }
        z = 0;
    }
            //add_token_to_list(info, current_token, is_first_token ? CMD : (expect_file ? FIL : ARG));
            current_section = append_to_current_section(info, current_section, current_token);
            //my_free(current_token);
            current_token = NULL;
            j = reset_positions(start_pos, size_malloc);
            j = 0;
            quote_state = NONE;
        }
        //is_first_token = 0;
        //expect_file = 0;
        i++;
        continue;  // Saltar el salto de línea para continuar
    }
        
        // Manejo de comillas dobles
        if (section[i] == '\"') {
            if (!in_single_quotes) {        
                in_double_quotes = !in_double_quotes;
                if (in_double_quotes) {
                    quote_state = DOUBLE_QUOTE;
                }
                current_token = add_char_to_token2(info, current_token, section[i]);
                // No cambiar `quote_state` al cerrar comillas dobles
            } else {
                current_token = add_char_to_token2(info, current_token, section[i]);
                if(section[i] == '$' && !in_single_quotes && current_token) {
                    start_pos[j] = strlen(current_token);
                    j++;
                }
                
            }
            i++;
            continue;
        }

        // Manejo de comillas simples
        if (section[i] == '\'') {
            if (!in_double_quotes) {
                in_single_quotes = !in_single_quotes;
                if (in_single_quotes) {
                    quote_state = SINGLE_QUOTE;
                }
                current_token = add_char_to_token2(info, current_token, section[i]);
                // No cambiar `quote_state` al cerrar comillas simples
            } else {
                current_token = add_char_to_token2(info, current_token, section[i]);
                    if(section[i] == '$' && !in_single_quotes && current_token) {
                    start_pos[j] = strlen(current_token);
                    j++;
                }
                
                
            }
            i++;
            continue;
        }

        // Manejo de >> como un token individual
        if (section[i] == '>' && section[i + 1] == '>' && !in_single_quotes && !in_double_quotes) {
            if (current_token) {
        
                //add_token_to_list(info, current_token, is_first_token ? CMD : ARG);
                current_section = append_to_current_section(info, current_section, current_token);
                //(current_token);
                current_token = NULL;
                j=reset_positions(start_pos, size_malloc);
                j = 0;
                quote_state = NONE;
            }
            //add_token_to_list(info, ">>", APPEND);
            current_section = append_to_current_section(info, current_section, ">>");
            //my_free(current_token);
            current_token = NULL;
            i++;
            //expect_file = 1;
            //is_first_token = 0;
            j=reset_positions(start_pos, size_malloc);
            j = 0;
            quote_state = NONE;
        }
        // Manejo de > como token individual
        else if (section[i] == '>' && section[i + 1] != '>' && !in_single_quotes && !in_double_quotes) {
            if (current_token) {
                //add_to_list(info, current_token, is_first_token ? CMD : ARG);
                current_section = append_to_current_section(info, current_section, current_token);
                //my_free(current_token);
                current_token = NULL;
                j=reset_positions(start_pos, size_malloc);
                j = 0;
                quote_state = NONE;
            }
            //add_token_to_list(info, ">", TRUNC);
            current_section = append_to_current_section(info, current_section, ">");
            //my_free(current_token);
            current_token = NULL;
            //expect_file = 1;
            //is_first_token = 0;
            j=reset_positions(start_pos, size_malloc);
            j = 0;
            quote_state = NONE;
        }
        // Manejo de < como token individual
        else if (section[i] == '<' && section[i + 1] == '<' && !in_single_quotes && !in_double_quotes) {
            if (current_token) {
        
                //add_token_to_list(info, current_token, is_first_token ? CMD : ARG);
                current_section = append_to_current_section(info, current_section, current_token);
                //my_free(current_token);
                current_token = NULL;
                j=reset_positions(start_pos, size_malloc);
                j = 0;
                quote_state = NONE;
            }
            
            current_section = append_to_current_section(info, current_section, "<<");
            //my_free(current_token);
            i++;
            //expect_file = 1;
            //is_first_token = 0;
            j=reset_positions(start_pos, size_malloc);
            j = 0;
            quote_state = NONE;
        }
        // Manejo de > como token individual
        else if (section[i] == '<' && section[i + 1] != '<' && !in_single_quotes && !in_double_quotes) {
            if (current_token) {
                //add_to_list(info, current_token, is_first_token ? CMD : ARG);
                current_section = append_to_current_section(info, current_section, current_token);
                //my_free(current_token);
                current_token = NULL;
                j=reset_positions(start_pos, size_malloc);
                j = 0;
                quote_state = NONE;
            }
            //add_token_to_list(info, ">", TRUNC);
            current_section = append_to_current_section(info, current_section, "<");
            //my_free(current_token);
            current_token = NULL;
            //expect_file = 1;
            //is_first_token = 0;
            j=reset_positions(start_pos, size_malloc);
            j = 0;
            quote_state = NONE;
        }
    
        // Manejo de | solo si no estamos dentro de comillas
        else if (section[i] == '|' && !in_single_quotes && !in_double_quotes) {
            //is_first_token = 1;
            if (current_token) {
        if (quote_state != SINGLE_QUOTE && count_dollars(section)) {
                while (z < size_malloc && start_pos[z] != -1) {
                    length_difference = calculate_length_difference(current_token, start_pos[z],info);
                    current_token = expand_variable2(current_token, start_pos[z],info);
                    while (h < size_malloc && start_pos[h] != -1) {
                        if(start_pos[h] + length_difference >= 0) {
                            start_pos[h] += length_difference;
                        }
                        
                        h++;
       	             }
                    z++;
                    h = 0;
        }
        z = 0;
    }
                //add_token_to_list(info, current_token, is_first_token ? CMD : ARG);
                current_section = append_to_current_section(info, current_section, current_token);
                //my_free(current_token);
                current_token = NULL;
                j=reset_positions(start_pos, size_malloc);
                j = 0;
                quote_state = NONE;
            }
            while (section[i] == '|') {
                //add_token_to_list(info, "|", PIPE);
                current_section = append_to_current_section(info, current_section, "|");
                //my_free(current_token);
                current_token = NULL;
                i++;
                //is_first_token = 1;
                j=reset_positions(start_pos, size_malloc);
                j = 0;
                quote_state = NONE;
            }
            continue;
        }
        // Manejo de espacios o tabuladores si no estamos dentro de comillas
        else if (ft_isspace(section[i]) && !in_single_quotes && !in_double_quotes) {
            if (current_token) {
       // if (quote_state != SINGLE_QUOTE && count_dollars(section)) {
          if (!in_single_quotes && count_dollars(section)) {    
		    while (z < size_malloc && start_pos[z] != -1) {
                    length_difference = calculate_length_difference(current_token, start_pos[z],info);
                    current_token = expand_variable2(current_token, start_pos[z],info);
                    while (h < size_malloc && start_pos[h] != -1) {
                        if(start_pos[h] + length_difference >= 0) {
                            start_pos[h] += length_difference;
                        }
                        
                        h++;
                    }
                    z++;
                    h = 0;
        }
        z = 0;
    }
                //add_token_to_list(info, current_token, is_first_token ? CMD : (expect_file ? FIL : ARG));
                current_section = append_to_current_section(info, current_section, current_token);
                //my_free(current_token);
                current_token = NULL;
                j=reset_positions(start_pos, size_malloc);
                j = 0;
                quote_state=NONE;
                //is_first_token = 0;
            }
            
                //is_first_token = 0;
        
            //is_first_token = 0;
            //expect_file = 0;
        }
        else {
            // Añadir carácter a current_token
                current_token = add_char_to_token2(info, current_token, section[i]);
                if(section[i] == '$' && !in_single_quotes && current_token) {
                    start_pos[j] = strlen(current_token);
                    j++;
                }
            
        }

        i++;
    }
    //if (count_dollars(section))
        //print_start_pos(start_pos);
    // Manejo final del token si existe
if (current_token) {
    // Si hay variables de entorno a expandir y no estamos en comillas simples
       // if (quote_state != SINGLE_QUOTE && count_dollars(section)) {
       if (!in_single_quotes && count_dollars(section)) {
		while (z < size_malloc && start_pos[z] != -1) {
                    length_difference = calculate_length_difference(current_token, start_pos[z],info);
                    current_token = expand_variable2(current_token, start_pos[z],info);
                    while (h < size_malloc && start_pos[h] != -1) {
                        if(start_pos[h] + length_difference >= 0) {
                            start_pos[h] += length_difference;
                        }
                        
                        h++;
                    }
                    z++;
                    h = 0;
        }
        z = 0;
    }
    
    // Añadir el último token a la lista
    //add_token_to_list(info, current_token, is_first_token ? CMD : (expect_file ? FIL : ARG));
    current_section = append_to_current_section(info, current_section, current_token);
    //my_free(current_token);
    current_token = NULL;
    j = reset_positions(start_pos, size_malloc);
    j = 0;
    quote_state = NONE;
    //irst_token = 0;
}

// Aquí puedes liberar start_pos si fue utilizado
//if (count_dollars(section))
//    free(start_pos);

if (current_section)
	trim_trailing_whitespace(current_section);
//free(current_token);
//free(length_difference);
//if (current_token)
    //my_free(current_token);
//if (start_pos != NULL) 
    //my_free(start_pos);
return current_section;    
}
//printf("Tokens concatenados2: %s\n", current_section);




void extract_tokens(const char *section, t_general *info) {
    char *current_token = NULL;  // Única variable para construcción de tokens
    int i = 0;
    int is_first_token = 1;      // Indicador de primer token en la sección
    int expect_file = 0;         // Indicador para identificar si el próximo token es un FILE
    int in_single_quotes = 0;    // Controla el estado de las comillas simples
    int in_double_quotes = 0;    // Controla el estado de las comillas dobles
    //QuoteState quote_state = NONE; // Inicialización de la variable de estado
    int *start_pos = NULL;
    int size_malloc;
    int j = 0;
    

    if (section && count_dollars(section) > 0) {
        size_malloc = count_dollars(section);
        start_pos = my_malloc(info, size_malloc * sizeof(int)); // size_t
        if (start_pos == NULL) {
            fprintf(stderr, "Error allocating memory\n");
            exit(EXIT_FAILURE);
        }
        for (int k = 0; k < size_malloc; k++) {
            start_pos[k] = -1;
        }
        //print_start_pos(start_pos);
    }

    
    while (section[i] != '\0') {

         // Manejo del salto de línea ('\n')
    
        // Manejo de comillas dobles
        if (section[i] == '\"') {
            if (!in_single_quotes) {        
                in_double_quotes = !in_double_quotes;
                if (in_double_quotes) {
                   // quote_state = DOUBLE_QUOTE;
                }
                // No cambiar `quote_state` al cerrar comillas dobles
            } else {
                current_token = add_char_to_token(info, current_token, section[i]);
                if(section[i] == '$' && !in_single_quotes && current_token) {
                    start_pos[j] = strlen(current_token);
                    j++;
                }
                
            }
            i++;
            continue;
        }

        // Manejo de comillas simples
        if (section[i] == '\'') {
            if (!in_double_quotes) {
                in_single_quotes = !in_single_quotes;
                if (in_single_quotes) {
                  //  quote_state = SINGLE_QUOTE;
                }
                // No cambiar `quote_state` al cerrar comillas simples
            } else {
                current_token = add_char_to_token(info, current_token, section[i]);
                    if(section[i] == '$' && !in_single_quotes && current_token) {
                    start_pos[j] = strlen(current_token);
                    j++;
                }
                
                
            }
            i++;
            continue;
        }

        // Manejo de >> como un token individual
        if (section[i] == '>' && section[i + 1] == '>' && !in_single_quotes && !in_double_quotes) {
            if (current_token) {
        
                add_token_to_list(info, current_token, is_first_token ? CMD : ARG);
                //my_free(current_token);
                current_token = NULL;
                j=reset_positions(start_pos, size_malloc);
                j = 0;
               // quote_state = NONE;
            }
            add_token_to_list(info, ">>", APPEND);
            //my_free(current_token);
            current_token = NULL; 
            i++;
            expect_file = 1;
            //is_first_token = 0;
            j=reset_positions(start_pos, size_malloc);
            j = 0;
           // quote_state = NONE;
        }
        // Manejo de > como token individual
        else if (section[i] == '>' && section[i + 1] != '>' && !in_single_quotes && !in_double_quotes) {
            if (current_token) {
                add_token_to_list(info, current_token, is_first_token ? CMD : ARG);
                //my_free(current_token);
                current_token = NULL;
                j=reset_positions(start_pos, size_malloc);
                j = 0;
              //  quote_state = NONE;
            }
            add_token_to_list(info, ">", TRUNC);
            //my_free(current_token);
            current_token = NULL;
            expect_file = 1;
            //is_first_token = 0;
            j=reset_positions(start_pos, size_malloc);
            j = 0;
           // quote_state = NONE;
        }
        else if (section[i] == '<' && section[i + 1] == '<' && !in_single_quotes && !in_double_quotes) {
            if (current_token) {
        
                add_token_to_list(info, current_token, is_first_token ? CMD : ARG);
                //my_free(current_token);
                current_token = NULL;
                j=reset_positions(start_pos, size_malloc);
                j = 0;
              //  quote_state = NONE;
            }
            add_token_to_list(info, "<<", INPUT);
            //my_free(current_token);
            current_token = NULL; 
            i++;
            expect_file = 1;
            is_first_token = 0;
            j=reset_positions(start_pos, size_malloc);
            j = 0;
           // quote_state = NONE;
        }
        // Manejo de < como token individual
        else if (section[i] == '<' && !in_single_quotes && !in_double_quotes) {
            if (current_token) {

                add_token_to_list(info, current_token, is_first_token ? CMD : ARG);
                //my_free(current_token);
                current_token = NULL;
                j=reset_positions(start_pos, size_malloc);
                j = 0;
               // quote_state = NONE;
            }
            add_token_to_list(info, "<", INPUT);
            //my_free(current_token);
            current_token = NULL;
            expect_file = 1;
            //is_first_token = 0;
            j=reset_positions(start_pos, size_malloc);
            j = 0;
            //quote_state = NONE;
        }
        // Manejo de | solo si no estamos dentro de comillas
        else if (section[i] == '|' && !in_single_quotes && !in_double_quotes) {
            is_first_token = 1;
            if (current_token) {

                add_token_to_list(info, current_token, is_first_token ? CMD : ARG);
                //my_free(current_token);
                current_token = NULL;
                j=reset_positions(start_pos, size_malloc);
                j = 0;
                //quote_state = NONE;
            }
            while (section[i] == '|') {
                add_token_to_list(info, "|", PIPE);
                //my_free(current_token);
                current_token = NULL;
                i++;
                is_first_token = 1;
                j=reset_positions(start_pos, size_malloc);
                j = 0;
                //quote_state = NONE;
            }
            continue;
        }
        // Manejo de espacios o tabuladores si no estamos dentro de comillas
        else if (ft_isspace(section[i]) && !in_single_quotes && !in_double_quotes) {
            if (current_token) {

                add_token_to_list(info, current_token, expect_file ? FIL : (is_first_token ? CMD : ARG));
                //my_free(current_token);
                current_token = NULL;
                j=reset_positions(start_pos, size_malloc);
                j = 0;
               //quote_state=NONE;
               //ES  AQUIIIII   is_first_token = 0;
				if (expect_file == 0)
					is_first_token = 0;
				expect_file = 0;
            }
        
        }
        else {
            // Añadir carácter a current_token
                current_token = add_char_to_token(info, current_token, section[i]);
                if(section[i] == '$' && !in_single_quotes && current_token) {
                    start_pos[j] = strlen(current_token);
                    j++;
                }
            
        }

        i++;
    }
    //if (count_dollars(section))
        //print_start_pos(start_pos);
    // Manejo final del token si existe
if (current_token)
{
    // Añadir el último token a la lista
    //add_token_to_list(info, current_token, is_first_token ? CMD : (expect_file ? FIL : ARG));
    add_token_to_list(info, current_token, expect_file ? FIL : (is_first_token ? CMD : ARG));
	//my_free(current_token);
    current_token = NULL;

    // Resetear posiciones
    j = reset_positions(start_pos, size_malloc);
    j = 0;
    //quote_state = NONE;
    is_first_token = 0;
}

// Aquí puedes liberar start_pos si fue utilizado
//if (start_pos)
//if (start_pos != NULL) 
    //my_free(start_pos);
//if (current_token)
    //my_free(current_token);


}



