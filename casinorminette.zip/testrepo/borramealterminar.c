/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   borramealterminar.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: albealva <albealva@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/14 11:59:37 by albealva          #+#    #+#             */
/*   Updated: 2024/11/14 17:10:48 by albealva         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char *expand_variable2(const char *input, int start_pos, t_general *info)
{   
    t_args *args;

    args = &(info->args);
    initialize_args(&(info->args), input);

    
    for (int j = 0; j < start_pos - 1; j++) {
        args->temp[args->temp_index++] = input[j];
    }
    if (start_pos == 0) {
        args->temp[args->temp_index++] = input[0];
    }

    for (int i = start_pos - 1; i < args->len; i++) {
        if (input[i] == '$' && input[i + 1] == '?' && !args->expanded) {
            i += 1;
            args->exit_status_str = expand_dollar_question(info);
            if (args->exit_status_str != NULL) {
                ft_strcpy(args->temp + args->temp_index, args->exit_status_str);
                args->temp_index += ft_strlen(args->exit_status_str);
            }
            args->expanded = 1;
            continue;
        }
        if (input[i] == '$' && input[i + 1] == '0' && !args->expanded) {
            ft_strcpy(args->temp + args->temp_index, "minishell");
            args->temp_index += ft_strlen("minishell");
            i++;
            args->expanded = 1;
            continue;
        }
        if (input[i] == '$' && input[i + 1] >= '1' && input[i + 1] <= '9' && !args->expanded) {
            i++;
            args->expanded = 1;
            continue;
        }
        if (input[i] == '$' && !args->expanded) {
            i++;
            if (i >= args->len || !(ft_isalnum(input[i]) || input[i] == '_')) {
                args->temp[args->temp_index++] = '$';
                if (i < args->len) {
                    args->temp[args->temp_index++] = input[i];
                }
                args->expanded = 1;
                continue;
            }
            args->var_index = 0;
            while (i < args->len && !is_special_separator(input[i]) && (ft_isalnum(input[i]) || input[i] == '_')) {
                args->var_name[args->var_index++] = input[i++];
            }
            i--;
            args->var_name[args->var_index] = '\0';
            char *value = get_env_var(info, args->var_name);
            if (value) {
                for (int k = 0; value[k] != '\0'; k++) {
                    if (value[k] == '"' || value[k] == '\'' || value[k] == '$') {
                        args->temp[args->temp_index++] = mark_char(value[k]);
                    } else {
                        args->temp[args->temp_index++] = value[k];
                    }
                }
            }
            args->expanded = 1;
        } else {
            args->temp[args->temp_index++] = input[i];
        }
    }

    args->result = trolft_strdup(args->temp, info);
    return args->result;
}




int check_syntax_errors(t_general *info)
{
    t_token *current_token = info->tokens_list;
    int last_type = 0;
	
	if (!current_token)
		return 1;
    // Verificar que el primer token no sea una pipe
    if (current_token && current_token->type == PIPE) {
        fprintf(stderr, "Error: Pipe error\n");
		Global_status = 2;	
        return 1;  // Error de sintaxis, no continuar la ejecución
    }

    // Verificar el primer token que sea un comando válido
    if (current_token && current_token->type == CMD) {
        if (!is_valid_command(info, current_token->str, info->env)) {
            fprintf(stderr, "Error: Command '%s' not found.\n", current_token->str);
			Global_status = 2;
            return 1;  // Error de sintaxis, no continuar la ejecución
        }
        last_type = CMD; // Actualiza el tipo del último token
    }
    
    // Avanzar al siguiente token
    current_token = current_token->next;

    while (current_token != NULL) {
        if (current_token->type == CMD) {
            // Verificar si el comando es válido
            if (!is_valid_command(info, current_token->str, info->env)) {
                fprintf(stderr, "Error: Command '%s' not found.\n", current_token->str);
				Global_status = 2;
                return 1;  // Error de sintaxis, no continuar la ejecución
            }
            last_type = CMD;

        } else if (current_token->type == ARG) {
            if (last_type == PIPE) {
                fprintf(stderr, "Error: Argument '%s' in invalid position after pipe.\n", current_token->str);
                Global_status = 2;
				return 1;  // Error de sintaxis, no continuar la ejecución
            }
            last_type = ARG;

        } else if (current_token->type == TRUNC || current_token->type == APPEND || current_token->type == INPUT) {
            // Verificación común para operadores de redirección
            if (last_type != CMD && last_type != ARG) {
                fprintf(stderr, "Error: Redirection operator '%s' in invalid position.\n", 
                        current_token->type == TRUNC ? ">" : current_token->type == APPEND ? ">>" : "<");
                Global_status = 2;
				return 1;  // Error de sintaxis, no continuar la ejecución
            }

            // Verificar que el siguiente token sea un archivo
            if (current_token->next == NULL || current_token->next->type != FIL) {
                fprintf(stderr, "Error: No file specified for redirection '%s'.\n", 
                        current_token->type == TRUNC ? ">" : current_token->type == APPEND ? ">>" : "<");
                Global_status = 2;
				return 1;  // Error de sintaxis, no continuar la ejecución
            }

            // Actualiza last_type y avanza al token de archivo
            last_type = FIL;
            current_token = current_token->next;

        } else if (current_token->type == PIPE) {
            if (last_type == PIPE || last_type == TRUNC || last_type == APPEND || last_type == INPUT) {
                fprintf(stderr, "Error: Pipe operator in invalid position.\n");
				Global_status = 2;
                return 1;  // Error de sintaxis, no continuar la ejecución
            }
            last_type = PIPE;
        }

        // Avanza al siguiente token
        current_token = current_token->next;
    }

    // Comprobar que el último token no sea una pipe o un operador de redirección
    if (last_type == PIPE || last_type == TRUNC || last_type == APPEND || last_type == INPUT) {
        fprintf(stderr, "Error: Incomplete command, expected an argument or command after '%s'.\n",
                last_type == PIPE ? "|" : last_type == TRUNC ? ">" : last_type == APPEND ? ">>" : "<");
        Global_status = 2;
		return 1;  // Error de sintaxis, no continuar la ejecución
    }

    return 0;  // No hay errores de sintaxis
}