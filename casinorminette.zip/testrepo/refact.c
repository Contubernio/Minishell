/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   refact.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: albealva <albealva@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/14 15:24:58 by albealva          #+#    #+#             */
/*   Updated: 2024/11/14 17:06:50 by albealva         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char *expand_variable2(const char *input, int start_pos, t_general *info)
{   
    t_args *args;

    args = &(info->args);
    initialize_args(&(info->args), input);
    copy_until_start_pos(input, args, start_pos);
    for (int i = start_pos - 1; i < args->len; i++) {
        if (input[i] == '$' && input[i + 1] == '?' && !args->expanded) {
            i += 1;
            args->exit_status_str = expand_dollar_question(info);
            if (args->exit_status_str != NULL) {
                ft_strcpy(args->temp + args->temp_index, args->exit_status_str);
                args->temp_index += ft_strlen(args->exit_status_str);
            }
            args->expanded = 1;
            continue;
        }
        if (input[i] == '$' && input[i + 1] == '0' && !args->expanded) {
            ft_strcpy(args->temp + args->temp_index, "minishell");
            args->temp_index += ft_strlen("minishell");
            i++;
            args->expanded = 1;
            continue;
        }
        if (input[i] == '$' && input[i + 1] >= '1' && input[i + 1] <= '9' && !args->expanded) {
            i++;
            args->expanded = 1;
            continue;
        }
        if (input[i] == '$' && !args->expanded) {
            i++;
            if (i >= args->len || !(ft_isalnum(input[i]) || input[i] == '_')) {
                args->temp[args->temp_index++] = '$';
                if (i < args->len) {
                    args->temp[args->temp_index++] = input[i];
                }
                args->expanded = 1;
                continue;
            }
            args->var_index = 0;
            while (i < args->len && !is_special_separator(input[i]) && (ft_isalnum(input[i]) || input[i] == '_')) {
                args->var_name[args->var_index++] = input[i++];
            }
            i--;
            args->var_name[args->var_index] = '\0';
            char *value = get_env_var(info, args->var_name);
            if (value) {
                for (int k = 0; value[k] != '\0'; k++) {
                    if (value[k] == '"' || value[k] == '\'' || value[k] == '$') {
                        args->temp[args->temp_index++] = mark_char(value[k]);
                    } else {
                        args->temp[args->temp_index++] = value[k];
                    }
                }
            }
            args->expanded = 1;
        } else {
            args->temp[args->temp_index++] = input[i];
        }
    }

    args->result = trolft_strdup(args->temp, info);
    return args->result;
}



char *expand_variable2(const char *input, int start_pos, t_general *info)
{   
    t_args *args;

    args = &(info->args);
    initialize_args(&(info->args), input);
    copy_until_start_pos(input, args, start_pos);
    for (int i = start_pos - 1; i < args->len; i++) {
        if (input[i] == '$' && input[i + 1] == '?' && !args->expanded) {
            i += 1;
            args->exit_status_str = expand_dollar_question(info);
            if (args->exit_status_str != NULL) {
                ft_strcpy(args->temp + args->temp_index, args->exit_status_str);
                args->temp_index += ft_strlen(args->exit_status_str);
            }
            args->expanded = 1;
            continue;
        }
        if (input[i] == '$' && input[i + 1] == '0' && !args->expanded) {
            ft_strcpy(args->temp + args->temp_index, "minishell");
            args->temp_index += ft_strlen("minishell");
            i++;
            args->expanded = 1;
            continue;
        }
        if (input[i] == '$' && input[i + 1] >= '1' && input[i + 1] <= '9' && !args->expanded) {
            i++;
            args->expanded = 1;
            continue;
        }
        if (input[i] == '$' && !args->expanded) {
            i++;
            if (i >= args->len || !(ft_isalnum(input[i]) || input[i] == '_')) {
                args->temp[args->temp_index++] = '$';
                if (i < args->len) {
                    args->temp[args->temp_index++] = input[i];
                }
                args->expanded = 1;
                continue;
            }
            args->var_index = 0;
            while (i < args->len && !is_special_separator(input[i]) && (ft_isalnum(input[i]) || input[i] == '_')) {
                args->var_name[args->var_index++] = input[i++];
            }
            i--;
            args->var_name[args->var_index] = '\0';
            char *value = get_env_var(info, args->var_name);
            if (value) {
                for (int k = 0; value[k] != '\0'; k++) {
                    if (value[k] == '"' || value[k] == '\'' || value[k] == '$') {
                        args->temp[args->temp_index++] = mark_char(value[k]);
                    } else {
                        args->temp[args->temp_index++] = value[k];
                    }
                }
            }
            args->expanded = 1;
        } else {
            args->temp[args->temp_index++] = input[i];
        }
    }

    args->result = trolft_strdup(args->temp, info);
    return args->result;
}


char *advance_until_delim(char *start, const char *delim)
{
    while (*start && ft_strchr(delim, *start))  // Avanza mientras haya un delimitador
        start++;
    return start;
}
int advance_until_delim_with_index(char *start, const char *delim, int i)
{
    while (start[i] && !ft_strchr(delim, start[i]))  // Avanza mientras no haya un delimitador
        i++;
    return i;
}

char *ft_strtok(char *str, const char *delim)
{
    static char *last;  // Variable estática para recordar el estado entre llamadas
    char *start;
    int i;

    if (str != NULL)
        last = str; 
    if (last == NULL)  // Si ya no quedan tokens
        return NULL;
    start = last;
    start = advance_until_delim(start, delim);
    if (*start == '\0')  // Si ya no hay más tokens
    {
        last = NULL;
        return NULL;
    }
    i = 0;
    i = advance_until_delim_with_index(start, delim, i);
    if (start[i] != '\0')
    {
        start[i] = '\0';  // Termina el token con '\0'
        last = &start[i + 1];  // Actualiza last para la siguiente llamada
    }
    else
        last = NULL;  // Si no hay más tokens
    return start;
}
