		else if (section[ex.i] == '<' && !ex.in_single_quotes && !ex.in_double_quotes) {
		if (ex.current_token) {
		if (ex.quote_state != SINGLE_QUOTE && count_dollars(section)) {
				while (ex.z < ex.size_malloc && ex.start_pos[ex.z] != -1) {
					ex.length_difference = calculate_length_difference(ex.current_token, ex.start_pos[ex.z],info);
					ex.current_token = expand_variable(ex.current_token, ex.start_pos[ex.z],info);
					while (ex.h < ex.size_malloc && ex.start_pos[ex.h] != -1) {
						if(ex.start_pos[ex.h] + ex.length_difference >= 0) {
							ex.start_pos[ex.h] += ex.length_difference;
						}
						
						ex.h++;
					}
					ex.z++;
					ex.h = 0;
		}
		ex.z = 0;
	}
				add_token_to_list(info, ex.current_token, ex.is_first_token ? CMD : ARG);
				free(ex.current_token);
				ex.current_token = NULL;
				ex.j=reset_positions(ex.start_pos, ex.size_malloc);
				ex.j = 0;
				ex.quote_state = NONE;
			}
			add_token_to_list(info, "<", INPUT);
			free(ex.current_token);
			ex.current_token = NULL;
			ex.expect_file = 1;
			//is_first_token = 0;
			ex.j=reset_positions(ex.start_pos, ex.size_malloc);
			ex.j = 0;
			ex.quote_state = NONE;
		}