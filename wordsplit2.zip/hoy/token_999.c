/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   token_999.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: albealva <albealva@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/10/15 19:03:14 by albealva          #+#    #+#             */
/*   Updated: 2024/10/15 21:02:15 by albealva         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"
#include <readline/readline.h>
#include <readline/history.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char	*itoa(int value, char *str, int base)
{
	static char	digits[] = "0123456789abcdefghijklmnopqrstuvwxyz";
	char* 		p = str;
	int 		num = value;

	if (base < 2 || base > 36)
	{
		*p = '\0';
		return NULL;
	}
	if (num < 0) {
		*p++ = '-';
		num = -num;
	}
	char temp[33];
	char* q = temp;
	do
	{
		*q++ = digits[num % base];
		num /= base;
	}
	while(num);

	while (q > temp) {
		*p++ = *--q;
	}
	*p = '\0';

	return str;
}


/*int	is_valid_command(const char *command, char **env)
{
	(void)env;
	char *path = getenv("PATH");
	if (!path) {
		fprintf(stderr, "Error: PATH variable not found.\n");
		return 0;
	}

	char *path_copy = strdup(path);
	char *dir = strtok(path_copy, ":");

	// Creamos un buffer para las rutas completas de los comandos
	char full_path[512];

	while (dir != NULL) {
		snprintf(full_path, sizeof(full_path), "%s/%s", dir, command);

		if (access(full_path, X_OK) == 0) { 
			free(path_copy);
			return 1;  // El comando existe y es ejecutable
		}

		dir = strtok(NULL, ":");  // Siguiente directorio en PATH
	}

	free(path_copy);
	return 0;  // El comando no se encontró
}*/

// Función para verificar el primer token de la lista

/*int check_syntax_errors(t_general *info) {
	t_token *current_token = info->tokens_list;
	int last_type = 0;
	int error_found = 0;

	// Verificar el primer token
	if (current_token && current_token->type == CMD) {
		if (!is_valid_command(current_token->str, info->env)) {
			fprintf(stderr, "Error: Command '%s' not found.\n", current_token->str);
			return 1;  // Error de sintaxis
		}
		last_type = CMD; // Actualiza el tipo del último token
	} else {
		fprintf(stderr, "Error: No command found.\n");
		return 1;  // Error de sintaxis
	}

	// Avanzar al siguiente token
	current_token = current_token->next;

	while (current_token != NULL) {
		// Verifica el tipo de token actual
		if (current_token->type == CMD) {
			if (!is_valid_command(current_token->str, info->env)) {
				fprintf(stderr, "Error: Command '%s' not found.\n", current_token->str);
				return 1;
			}
			last_type = CMD; // Actualiza el tipo del último token
		} else if (current_token->type == ARG) {
			// Argumento puede seguir a un comando, otro argumento, o un operador de redirección
			if (last_type == PIPE) {
				fprintf(stderr, "Error: Argument '%s' in invalid position after pipe.\n", current_token->str);
				error_found = 1;
				break;
			}
			last_type = ARG; // Actualiza el tipo del último token
		} else if (current_token->type == TRUNC || current_token->type == APPEND) {
			// Redirección debe seguir a un comando o argumento
			if (last_type != CMD && last_type != ARG) {
				fprintf(stderr, "Error: Redirection operator '%d' in invalid position.\n", current_token->type);
				error_found = 1;
				break;
			}
			// Verifica que el siguiente token sea un archivo
			if (current_token->next == NULL || current_token->next->type != FIL) {
				fprintf(stderr, "Error: No file specified for redirection '%d'.\n", current_token->type);
				error_found = 1;
				break;
			}
			// Actualiza last_type después de procesar el archivo
			last_type = FIL;
			current_token = current_token->next; // Avanza al siguiente token
		} else if (current_token->type == INPUT) {
			// Redirección de entrada debe seguir a un comando o argumento
			if (last_type != CMD && last_type != ARG) {
				fprintf(stderr, "Error: Input redirection operator '%d' in invalid position.\n", current_token->type);
				error_found = 1; 
				break;
			}
			// Verifica que el siguiente token sea un archivo
			if (current_token->next == NULL || current_token->next->type != FIL) {
				fprintf(stderr, "Error: No file specified for input redirection.\n");
				error_found = 1;
				break;
			}
			// Actualiza last_type después de procesar el archivo
			last_type = FIL;
			current_token = current_token->next; // Avanza al siguiente token
		} else if (current_token->type == PIPE) {
			// La tubería debe seguir a un comando o argumento
			if (last_type == PIPE || last_type == TRUNC || last_type == APPEND || last_type == INPUT) {
				fprintf(stderr, "Error: Pipe operator in invalid position.\n");
				error_found = 1;  // Error de sintaxis
				break;
			}
			last_type = PIPE; // Actualiza el tipo del último token
		} else {
			fprintf(stderr, "Error: Unknown token type '%d'.\n", current_token->type);
			error_found = 1;  // Error de sintaxis
			break;
		}

		// Avanza al siguiente token
		current_token = current_token->next;
	}

	// Verifica que el último token no sea un operador sin un archivo o comando siguiente
	if (!error_found && (last_type == TRUNC || last_type == APPEND || last_type == INPUT || last_type == PIPE)) {
		fprintf(stderr, "Error: Command ends with an invalid operator.\n");
		error_found = 1;  // Error de sintaxis
	}

	return error_found ? 1 : 0;  // Retorna 1 si hubo un error, 0 si no
}
*/