/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: albealva <albealva@student.42barcelon      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/22 18:03:11 by albealva          #+#    #+#             */
/*   Updated: 2024/07/22 18:06:54 by albealva         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

void sigint_handler(int signo)
{
    if (signo == SIGINT)
    {
        printf("\n");
        rl_on_new_line();
        rl_replace_line("", 0);
        rl_redisplay();
    }
}

void sigquit_handler(int signo)
{
    if (signo == SIGQUIT)
    {
        printf("Quit: %d\n", signo);
    }
}

int init_general(t_general *info, char **env) {
    (void)env;
    // Inicializa el contenido relevante de t_general
    info->number_of_tokens = 0;
    info->tokens_list = NULL;
    return 0; // Devuelve un código de status (0 para éxito, otro valor para error)
}

int main(int argc, char **argv, char **env)
{
    (void)argc;
    (void)argv;
    char *input;
    char *input_dup;
    t_general info;
    const char *history_file = ".minishell_history";
    
    // Leer el historial desde el archivo al inicio
    read_history(history_file);

    // Configuración de las señales
    signal(SIGINT, sigint_handler);
    signal(SIGQUIT, sigquit_handler);

    while (1)
    {
        input = readline("mini> ");
        if (input == NULL) // Si readline retorna NULL, significa que se recibió EOF (Ctrl-D)
        {
            printf("exit\n");
            break;
        }

        // Checks parseo a full, verificar input OK
        // Inicializa t_general con el entorno actual
        if (init_general(&info, env) != 0) {
            fprintf(stderr, "Error initializing shell info\n");
            free(input);
            continue;
        }

        // Duplica la entrada antes de tokenizarla para mantener el original intacto
        input_dup = strdup(input);
        if (!input_dup) {
            fprintf(stderr, "minishell: allocation error\n");
            free(input);
            continue;
        }

        // Tokeniza usando la cadena duplicada
        info.tokens_list = tokenizer(&info, input_dup);
        free(input_dup); // Libera la cadena duplicada después de tokenizar

        // Aquí puedes imprimir los tokens para verificar su validez
        t_token *current = info.tokens_list;
        while (current)
        {
            printf("Token: %s, Type: %d\n", current->str, current->type);
            t_token *temp = current;
            current = current->next;
            free(temp->str); // Liberar cada string de token
            free(temp); // Liberar cada struct de token
        }

        if (*input)  // Si la línea de entrada no está vacía
            add_history(input);

        free(input); // Liberar la memoria asignada por readline
    }

    // Guardar el historial en el archivo antes de salir
    write_history(history_file);

    return 0;
}
