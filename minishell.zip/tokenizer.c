/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   tokenizer.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mgimon-c <mgimon-c@student.42barcelon      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/18 13:56:14 by mgimon-c          #+#    #+#             */
/*   Updated: 2024/07/22 18:13:01 by albealva         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"
#include <string.h>

t_token *create_token(char *str, int type)
{
    t_token *token = malloc(sizeof(t_token));
    if (!token)
    {
        fprintf(stderr, "minishell: allocation error\n");
        exit(EXIT_FAILURE);
    }

    token->str = str;
    token->type = type;
    token->prev = NULL;
    token->next = NULL;
    return token;
}

void add_token(t_general *info, t_token *new_token)
{
    t_token *last = info->tokens_list;

    if (!last)
    {
        info->tokens_list = new_token;
    }
    else
    {
        while (last->next)
            last = last->next;
        last->next = new_token;
        new_token->prev = last;
    }
    info->number_of_tokens++;
}

t_token *tokenizer(t_general *info, char *input)
{
    char *delimiters = " \t\r\n\a";
    char *token_str;
    t_token *token;

    info->tokens_list = NULL;
    info->number_of_tokens = 0;

    token_str = strtok(input, delimiters);
    while (token_str != NULL)
    {
        int type = CMD; // A simple assumption; real implementation will determine the actual type

        // Determine the type of the token (for simplicity, classify as CMD or ARG here)
        if (strcmp(token_str, "|") == 0)
            type = PIPE;
        else if (strcmp(token_str, ">") == 0)
            type = TRUNC;
        else if (strcmp(token_str, ">>") == 0)
            type = APPEND;
        else if (strcmp(token_str, "<") == 0)
            type = INPUT;
        
        token = create_token(strdup(token_str), type);
        add_token(info, token);

        token_str = strtok(NULL, delimiters);
    }

    return info->tokens_list;
}
