/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   expandint.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: albealva <albealva@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/18 20:44:44 by albealva          #+#    #+#             */
/*   Updated: 2024/09/18 20:44:46 by albealva         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <stdlib.h>

int last_exit_status = 0; // Variable global para almacenar el último código de salida

// Función para establecer el último código de salida
void set_last_exit_status(int status) {
    last_exit_status = status;
}

// Función para expandir "$?"
char* expand_dollar_question() {
    // Usamos itoa para convertir el código de salida en una cadena
    // Si itoa no está disponible en tu entorno, puedes usar sprintf
    char* result = (char*)malloc(12); // Asegúrate de tener suficiente espacio
    if (result == NULL) {
        return NULL; // Manejo de error si malloc falla
    }
    
    // Usa itoa si está disponible
    // itoa(last_exit_status, result, 10);

    // Alternativamente, usa sprintf para convertir el entero a cadena
    sprintf(result, "%d", last_exit_status);

    return result;
}

// Ejemplo de uso
int main() {
    // Simula la ejecución de un comando y establece el código de salida
    set_last_exit_status(42);

    // Expande "$?"
    char* exit_status_str = expand_dollar_question();
    if (exit_status_str != NULL) {
        printf("El último código de salida es: %s\n", exit_status_str);
        free(exit_status_str); // Libera la memoria asignada
    } else {
        printf("Error al expandir \"$?\"\n");
    }

    return 0;
}