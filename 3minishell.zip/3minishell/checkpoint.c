/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   checkpoint.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: albealva <albealva@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/13 18:24:02 by albealva          #+#    #+#             */
/*   Updated: 2024/09/13 19:56:54 by albealva         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int reset_positions(int *start_pos, int size_malloc) {
    int k;
    if(start_pos == NULL) {
        return (-1);
    }
    for(k = 0; k < size_malloc; k++){
            start_pos[k] = -1; // Inicializar todos los valores en start_pos a -1
        }
    return (0);
}



void add_expanded_tokens(char *current_token, t_general *info, int *start_pos) {
    int z = 0;
    while (start_pos[z] != -1) {
        current_token = expand_variable(current_token, start_pos[z]);
        z++;
    }
    add_token_to_list(info, current_token, 0);  // Cambiar '0' por el tipo adecuado según lógica
}




void extract_tokens(const char *section, t_general *info) {
    char *current_token = NULL;  // Única variable para construcción de tokens
    int i = 0;
    int is_first_token = 1;      // Indicador de primer token en la sección
    int expect_file = 0;         // Indicador para identificar si el próximo token es un FILE
    int in_single_quotes = 0;    // Controla el estado de las comillas simples
    int in_double_quotes = 0;    // Controla el estado de las comillas dobles
    QuoteState quote_state = NONE; // Inicialización de la variable de estado
    int *start_pos = NULL;
    int size_malloc;
    int j = 0;
    int z = 0;
    //size_t pos_ini_8 = 8;  // Posición inicial fija para pruebas

    if (section && count_dollars(section) > 0) {
        size_malloc = count_dollars(section);
        start_pos = malloc(size_malloc * sizeof(int)); // size_t
        if (start_pos == NULL) {
            fprintf(stderr, "Error allocating memory\n");
            exit(EXIT_FAILURE);
        }
        for (int k = 0; k < size_malloc; k++) {
            start_pos[k] = -1;
        }
        //print_start_pos(start_pos);
    }

    
    while (section[i] != '\0') {

         // Manejo del salto de línea ('\n')
    if (section[i] == '\n' && !in_single_quotes && !in_double_quotes) {
        if (current_token) {
            if (quote_state != SINGLE_QUOTE && count_dollars(section)) {
                while (start_pos[z] != -1) {
                    current_token = expand_variable(current_token, start_pos[z]);
                    z++;
                }
                z = 0;
            }
            add_token_to_list(info, current_token, is_first_token ? CMD : (expect_file ? FIL : ARG));
            free(current_token);
            current_token = NULL;
            j = reset_positions(start_pos, size_malloc);
            j = 0;
            quote_state = NONE;
        }
        is_first_token = 0;
        expect_file = 0;
        i++;
        continue;  // Saltar el salto de línea para continuar
    }
        
        // Manejo de comillas dobles
        if (section[i] == '\"') {
            if (!in_single_quotes) {        
                in_double_quotes = !in_double_quotes;
                if (in_double_quotes) {
                    quote_state = DOUBLE_QUOTE;
                }
                // No cambiar `quote_state` al cerrar comillas dobles
            } else {
                if(section[i] == '$' && !in_single_quotes && current_token) {
                    start_pos[j] = strlen(current_token);
                    j++;
                }
                current_token = add_char_to_token(current_token, section[i]);
            }
            i++;
            continue;
        }

        // Manejo de comillas simples
        if (section[i] == '\'') {
            if (!in_double_quotes) {
                in_single_quotes = !in_single_quotes;
                if (in_single_quotes) {
                    quote_state = SINGLE_QUOTE;
                }
                // No cambiar `quote_state` al cerrar comillas simples
            } else {
                    if(section[i] == '$' && !in_single_quotes && current_token) {
                    start_pos[j] = strlen(current_token);
                    j++;
                }
                
                current_token = add_char_to_token(current_token, section[i]);
            }
            i++;
            continue;
        }

        // Manejo de >> como un token individual
        if (section[i] == '>' && section[i + 1] == '>' && !in_single_quotes && !in_double_quotes) {
            if (current_token) {
        
                add_token_to_list(info, current_token, is_first_token ? CMD : ARG);
                free(current_token);
                current_token = NULL;
                j=reset_positions(start_pos, size_malloc);
                j = 0;
                quote_state = NONE;
            }
            add_token_to_list(info, ">>", APPEND);
            i++;
            expect_file = 1;
            is_first_token = 0;
            j=reset_positions(start_pos, size_malloc);
            j = 0;
            quote_state = NONE;
        }
        // Manejo de > como token individual
        else if (section[i] == '>' && section[i + 1] != '>' && !in_single_quotes && !in_double_quotes) {
            if (current_token) {
                add_token_to_list(info, current_token, is_first_token ? CMD : ARG);
                free(current_token);
                current_token = NULL;
                j=reset_positions(start_pos, size_malloc);
                j = 0;
                quote_state = NONE;
            }
            add_token_to_list(info, ">", TRUNC);
            expect_file = 1;
            is_first_token = 0;
            j=reset_positions(start_pos, size_malloc);
            j = 0;
            quote_state = NONE;
        }
        // Manejo de < como token individual
        else if (section[i] == '<' && !in_single_quotes && !in_double_quotes) {
            if (current_token) {
                if (quote_state !=SINGLE_QUOTE) {
                //print_start_pos(start_pos);
                while(start_pos[z] != -1){
                    current_token = expand_variable(current_token, start_pos[z]);
                    z++;
                }
                z = 0;
                }
                add_token_to_list(info, current_token, is_first_token ? CMD : ARG);
                free(current_token);
                current_token = NULL;
                j=reset_positions(start_pos, size_malloc);
                j = 0;
                quote_state = NONE;
            }
            add_token_to_list(info, "<", INPUT);
            expect_file = 1;
            is_first_token = 0;
            j=reset_positions(start_pos, size_malloc);
            j = 0;
        }
        // Manejo de | solo si no estamos dentro de comillas
        else if (section[i] == '|' && !in_single_quotes && !in_double_quotes) {
            if (current_token) {
                if (quote_state !=SINGLE_QUOTE) {
                //print_start_pos(start_pos);
                while(start_pos[z] != -1){
                    current_token = expand_variable(current_token, start_pos[z]);
                    z++;
                }
                z = 0;
                }
                add_token_to_list(info, current_token, is_first_token ? CMD : ARG);
                free(current_token);
                current_token = NULL;
                j=reset_positions(start_pos, size_malloc);
                j = 0;
                quote_state = NONE;
            }
            while (section[i] == '|') {
                add_token_to_list(info, "|", PIPE);
                i++;
                is_first_token = 0;
                j=reset_positions(start_pos, size_malloc);
                j = 0;
            }
            continue;
        }
        // Manejo de espacios o tabuladores si no estamos dentro de comillas
        else if (ft_isspace(section[i]) && !in_single_quotes && !in_double_quotes) {
            if (current_token) {
                if (quote_state !=SINGLE_QUOTE && count_dollars(section)) {
                //print_start_pos(start_pos);
                while(start_pos[z] != -1){
                    current_token = expand_variable(current_token, start_pos[z]);
                    z++;
                }
                z = 0;
                }
                add_token_to_list(info, current_token, is_first_token ? CMD : (expect_file ? FIL : ARG));
                free(current_token);
                current_token = NULL;
                j=reset_positions(start_pos, size_malloc);
                j = 0;
                quote_state=NONE;
            }
            is_first_token = 0;
            expect_file = 0;
        }
        else {
            // Añadir carácter a current_token
                if(section[i] == '$' && !in_single_quotes && current_token) {
                    start_pos[j] = strlen(current_token);
                    j++;
                }
            
        }
        current_token = add_char_to_token(current_token, section[i]);

        i++;
    }
    if (count_dollars(section))
        //print_start_pos(start_pos);
    // Manejo final del token si existe
    if (current_token) {
        if (quote_state !=SINGLE_QUOTE) {
                //print_start_pos(start_pos);
                while(start_pos[z] != -1){
                    current_token = expand_variable(current_token, start_pos[z]);
                    z++;
        }
        z = 0;
        }
        quote_state = NONE;
        add_token_to_list(info, current_token, is_first_token ? CMD : (expect_file ? FIL : ARG));
        free(current_token);
        //print_start_pos(start_pos);
        j=reset_positions(start_pos, size_malloc);
        j = 0;
    }
    if (count_dollars(section))
        free(start_pos);
}