/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   expandint.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: albealva <albealva@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/18 20:44:44 by albealva          #+#    #+#             */
/*   Updated: 2024/09/18 21:11:38 by albealva         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <string.h>

int last_exit_status = 0; // Variable global para almacenar el último código de salida

// Implementación de itoa
char* itoa(int value, char* str, int base) {
    static char digits[] = "0123456789abcdefghijklmnopqrstuvwxyz";
    char* p = str;
    int num = value;

    if (base < 2 || base > 36) {
        *p = '\0';
        return NULL;
    }

    if (num < 0) {
        *p++ = '-';
        num = -num;
    }

    char temp[33];
    char* q = temp;

    do {
        *q++ = digits[num % base];
        num /= base;
    } while (num);

    while (q > temp) {
        *p++ = *--q;
    }
    *p = '\0';

    return str;
}

// Función para establecer el último código de salida
void set_last_exit_status(int status) {
    last_exit_status = status;
}

// Función para expandir "$?"
char* expand_dollar_question() {
    char* result = (char*)malloc(12); // Asegúrate de tener suficiente espacio
    if (result == NULL) {
        return NULL;
    }

    itoa(last_exit_status, result, 10);

    return result;
}

// Función para ejecutar un comando y actualizar el código de salida
void execute_command(const char* command) {
    pid_t pid = fork();
    if (pid == 0) {
        // Proceso hijo
        execlp(command, command, NULL);
        // Si execlp falla, exit con un código de salida 1
        exit(127); // Código de salida para comando no encontrado
    } else if (pid > 0) {
        // Proceso padre
        int status;
        waitpid(pid, &status, 0);
        if (WIFEXITED(status)) {
            set_last_exit_status(WEXITSTATUS(status));
        } else {
            set_last_exit_status(1); // En caso de error inesperado
        }
    } else {
        perror("fork failed");
        exit(1);
    }
}

// Función para procesar y expandir la entrada del usuario
char* process_input(const char* input) {
    char* expanded_input = (char*)malloc(strlen(input) * 2); // Reserva espacio suficiente
    if (expanded_input == NULL) {
        return NULL;
    }

    char* p = expanded_input;
    const char* q = input;

    while (*q) {
        if (*q == '$' && *(q + 1) == '?') {
            // Expande "$?"
            char* exit_status_str = expand_dollar_question();
            if (exit_status_str != NULL) {
                strcpy(p, exit_status_str);
                p += strlen(exit_status_str);
                free(exit_status_str);
            }
            q += 2;
        } else {
            *p++ = *q++;
        }
    }
    *p = '\0';

    return expanded_input;
}

int main() {
    char input[1024];

    while (1) {
        // Mostrar el prompt
        printf("mini-shell> ");
        fflush(stdout);

        // Leer la entrada del usuario
        if (fgets(input, sizeof(input), stdin) == NULL) {
            perror("fgets failed");
            exit(1);
        }

        // Eliminar el carácter de nueva línea
        input[strcspn(input, "\n")] = '\0';

        // Procesar la entrada para expandir "$?"
        char* processed_input = process_input(input);
        if (processed_input != NULL) {
            // Imprimir el resultado procesado
            printf("Processed Input: %s\n", processed_input);
            
            // Ejecutar el comando si no es simplemente "$?"
            if (strlen(processed_input) > 0 && strcmp(processed_input, "127") != 0) {
                execute_command(processed_input);
            }
            free(processed_input);
        } else {
            printf("Error al procesar la entrada.\n");
        }
    }

    return 0;
}

