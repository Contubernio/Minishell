/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   copiapreviaadejarcontrolachatgpt.c                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: albealva <albealva@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/13 15:59:46 by albealva          #+#    #+#             */
/*   Updated: 2024/09/13 16:00:05 by albealva         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   token_1.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: albealva <albealva@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/08 18:10:59 by albealva          #+#    #+#             */
/*   Updated: 2024/09/13 15:41:39 by albealva         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"
#include <readline/readline.h>
#include <readline/history.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

const char *get_token_type_name(int type) {
    static const char *token_type_names[] = {
        "EMPTY",  // 0
        "CMD",    // 1
        "ARG",    // 2
        "TRUNC",  // 3
        "APPEND", // 4
        "INPUT",  // 5
        "FIL",    // 6
        "PIPE",   // 7
        "END"     // 8
    };

    if (type >= 0 && type <= 8) {
        return token_type_names[type];
    } else {
        return "UNKNOWN";
    }
}

// Libera la memoria ocupada por la lista de tokens
void free_tokens_list(t_general *info) {
    t_token *current = info->tokens_list;
    t_token *next;

    while (current != NULL) {
        next = current->next;
        free(current->str);
        free(current);
        current = next;
    }
    info->tokens_list = NULL;
    info->number_of_tokens = 0;
}

void quoting_choice(t_quote_state *state, char c) {
    if (c == '"' && state->sq == 0) {  // Dentro de comillas simples
        if (state->dq == 0) {
            // No estamos dentro de comillas dobles, así que cambiamos el estado
            state->dq = 1;
        } else {
            // Estamos dentro de comillas dobles, así que cerramos
            state->dq = 0;
        }
    } else if (c == '\'' && state->dq == 0) {  // Dentro de comillas dobles
        if (state->sq == 0) {
            // No estamos dentro de comillas simples, así que cambiamos el estado
            state->sq = 1;
        } else {
            // Estamos dentro de comillas simples, así que cerramos
            state->sq = 0;
        }
    }
}


int open_quote(char *line, t_quote_state *state) {
    int i = 0;
    state->dq = 0;
    state->sq = 0;

    while (line[i] != '\0') {
        quoting_choice(state, line[i]);
        i++;
    }

    // Verificar el estado final
    if (state->dq != 0 || state->sq != 0) {
        // Hay comillas abiertas que no se han cerrado
        return 1;  // Error: comillas no cerradas
    }

    return 0;  // Sin errores
}


//////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////


// Extrae una sección del texto de entrada, considerando cada pipe como una sección independiente


#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Función para extraer una sección basada en delimitadores, manejando comillas
char *extract_section(char **start, const char *delimiters) {
    char *end;
    char *section;
    size_t section_length;
    int in_single_quotes = 0; // Controla el estado de las comillas simples
    int in_double_quotes = 0; // Controla el estado de las comillas dobles

    // Caso especial para manejar pipes (`|`) como secciones independientes
    if (**start == '|') {
        section = malloc(2); // Espacio para la pipe y el terminador nulo
        if (!section) {
            perror("Malloc failed");
            exit(EXIT_FAILURE);
        }
        section[0] = '|';
        section[1] = '\0';

        // Mueve el puntero para saltar la pipe
        (*start)++;

        // Imprime el contenido de la sección
        printf("Sección: %s\n", section);

        return section;
    }

    end = *start;
    while (*end && (!strchr(delimiters, *end) || in_single_quotes || in_double_quotes)) {
        if (*end == '\'') {
            in_single_quotes = !in_single_quotes; // Alterna el estado de las comillas simples
        } else if (*end == '\"') {
            in_double_quotes = !in_double_quotes; // Alterna el estado de las comillas dobles
        }
        end++;
    }

    // Calcula la longitud de la sección
    section_length = end - *start;

    // Asigna memoria para la sección
    section = malloc(section_length + 1); // +1 para el terminador nulo
    if (!section) {
        perror("Malloc failed");
        exit(EXIT_FAILURE);
    }

    // Copia la sección actual
    strncpy(section, *start, section_length);
    section[section_length] = '\0'; // Termina la cadena con '\0'

    // Mueve el puntero al final de la sección
    *start = end;

    // Imprime el contenido de la sección
    printf("Sección: %s\n", section);

    return section;
}









// Añade un token a la lista de tokens
void add_token_to_list(t_general *info, const char *str, int type) {
    t_token *new_token = malloc(sizeof(t_token));
    if (!new_token) {
        perror("Malloc failed");
        exit(EXIT_FAILURE);
    }

    new_token->str = strdup(str);
    if (!new_token->str) {
        perror("Strdup failed");
        exit(EXIT_FAILURE);
    }

    new_token->type = type;
    new_token->prev = NULL;
    new_token->next = NULL;

    if (!info->tokens_list) {
        info->tokens_list = new_token;
    } else {
        t_token *last = info->tokens_list;
        while (last->next) {
            last = last->next;
        }
        last->next = new_token;
        new_token->prev = last;
    }

    info->number_of_tokens++;
}

// Función para añadir un carácter a un string
char *add_char_to_token(char *token, char c) {
    size_t len = token ? strlen(token) : 0; // Calcular longitud actual del token
    char *new_token = malloc(len + 2);      // Reservar espacio para nuevo carácter y '\0'
    if (!new_token) {
        // Manejo de error de memoria (opcional)
        return NULL;
    }
    if (token) {
        strcpy(new_token, token);           // Copiar token existente
        free(token);                        // Liberar memoria del token anterior
    }
    new_token[len] = c;                     // Añadir nuevo carácter
    new_token[len + 1] = '\0';              // Terminar el string con '\0'
    return new_token;
}

// Función para verificar si un carácter es un espacio o tabulador
int ft_isspace(char c) {
    return (c == ' ' || c == '\t');
}



// Función para expandir una variable de entorno

/*char *expand_variable(const char *input) {
    char *result = NULL;
    size_t len = strlen(input);
    char temp[1024] = {0};  // Buffer temporal para construir el resultado expandido
    char var_name[256] = {0};
    size_t temp_index = 0;
    size_t var_index = 0;

    for (size_t i = 0; i < len; i++) {
        // Expansión de variables solo si no estamos dentro de comillas simples
        if (input[i] == '$') {
            i++;
            var_index = 0;
            while (i < len && (isalnum(input[i]) || input[i] == '_')) {
                var_name[var_index++] = input[i++];
            }
            i--;  // Retrocede un carácter porque el bucle ha avanzado uno de más.
            var_name[var_index] = '\0';

            char *value = get_env_var(var_name);
            if (value) {
                strcpy(temp + temp_index, value);
                temp_index += strlen(value);
            }
        } else {
            // Copia el contenido literal
            temp[temp_index++] = input[i];
        }
    }

    // Duplica el resultado expandido
    result = strdup(temp);
    return result;
}
*/








bool should_expand(bool in_single_quotes) {
    // Si estamos dentro de comillas simples, no expandir
    return !in_single_quotes;
}

typedef enum {
    NONE,
    SINGLE_QUOTE,
    DOUBLE_QUOTE
} QuoteState;

/*
char *get_env_var(const char *var_name) {
    char *value = getenv(var_name);
    return value ? value : "";  // Si la variable no está definida, devuelve una cadena vacía.
}
*/





char *get_env_var(const char *var_name) {
    printf("get_env_var called with: %s\n", var_name); // Imprimir el nombre de la variable recibida
    fflush(stdout); // Asegúrate de que se imprime inmediatamente
    char *value = getenv(var_name);
    printf("get_env_var returning: %s\n", value ? value : "NULL"); // Imprimir el valor devuelto o "NULL"
    fflush(stdout); // Asegúrate de que se imprime inmediatamente
    return value ? value : "";  // Si la variable no está definida, devuelve una cadena vacía.
}

int is_special_separator(char c) {
    return c == ' ' || c == '\t' || c == '\'' || c == '\"' || c == '<' || c == '>' || c == '|' || c == '$';
}

char *expand_variable(const char *input, size_t start_pos) {
    printf("expand_variable called with input: %s, start_pos: %zu\n", input, start_pos);
    fflush(stdout);

    char *result = NULL;
    size_t len = strlen(input);
    char temp[1024] = {0};  // Buffer temporal para construir el resultado expandido
    char var_name[256] = {0};
    size_t temp_index = 0;  // Índice para el buffer temporal
    size_t var_index = 0;
    int expanded = 0;  // Bandera para saber si ya hemos expandido una variable

    // Copia los caracteres iniciales antes de start_pos
    for (size_t j = 0; j < start_pos; j++) {
        temp[temp_index++] = input[j];
    }

    for (size_t i = start_pos; i < len; i++) {
        // Expandir solo a partir de start_pos y solo una vez
        if (input[i] == '$' && !expanded) {
            i++;  // Avanza para saltarse el '$'
            var_index = 0;
            // Captura el nombre de la variable de entorno
            while (i < len && !is_special_separator(input[i]) && (isalnum(input[i]) || input[i] == '_')) {
                var_name[var_index++] = input[i++];
            }
            i--;  // Retrocede un carácter porque el bucle ha avanzado uno de más.
            var_name[var_index] = '\0';

            // Obtiene el valor de la variable de entorno
            char *value = get_env_var(var_name);
            if (value) {
                strcpy(temp + temp_index, value);
                temp_index += strlen(value);
            }
            expanded = 1;  // Marca que ya hemos expandido una variable
        } else {
            // Copia el contenido literal al buffer temporal
            temp[temp_index++] = input[i];
        }
    }

    // Duplica el resultado expandido
    result = strdup(temp);
    printf("expand_variable returning: %s\n", result);
    fflush(stdout);
    return result;
}


int count_dollars(const char *section) {
    int count = 0;
    for (int i = 0; section[i] != '\0'; i++) {
        if (section[i] == '$') {
            count++;
        }
    }
    return count;
}

void print_start_pos(int *start_pos) {
    printf("Contenido de start_pos: ");
    int i = 0;
    while (start_pos[i]) {
        printf("%d ", start_pos[i]);
        i++;
    }
    printf("\n");
}



/*
void extract_tokens(const char *section, t_general *info) {
    char *current_token = NULL;  // Única variable para construcción de tokens
    char *expanded_token = NULL;
    int i = 0;
    int is_first_token = 1;      // Indicador de primer token en la sección
    int expect_file = 0;         // Indicador para identificar si el próximo token es un FILE
    int in_single_quotes = 0;    // Controla el estado de las comillas simples
    int in_double_quotes = 0;    // Controla el estado de las comillas dobles
    int *start_pos = NULL;  // Declarar e inicializar start_pos como puntero a NULL
    int size_malloc;
    int j = 0;
    QuoteState quote_state = NONE; // Inicialización de la variable de estado
    //size_t start_pos = 8;

if (section) {
    size_malloc = count_dollars(section);
    start_pos = malloc(size_malloc * sizeof(int));
    if (start_pos == NULL) {
        fprintf(stderr, "Error allocating memory\n");
        exit(EXIT_FAILURE);
    }
    // Inicializar todos los valores en start_pos a -1
    for (int k = 0; k < size_malloc; k++) {
        start_pos[k] = -1;
    }
}

    while (section[i] != '\0') {
        // Manejo de comillas dobles
        if (section[i] == '\"') {
            if (!in_single_quotes) {        
                in_double_quotes = !in_double_quotes;
                if (in_double_quotes) {
                    quote_state = DOUBLE_QUOTE;
                }
                // No cambiar `quote_state` al cerrar comillas dobles
            } else {
                if (section[i] == '$' && quote_state != SINGLE_QUOTE && current_token){
                    start_pos[j] = (strlen(current_token));  // Asignar la dirección de i a start_pos
                    j++;
                }
                    
                current_token = add_char_to_token(current_token, section[i]);
            }
            i++;
            continue;
        }

        // Manejo de comillas simples
        if (section[i] == '\'') {
            if (!in_double_quotes) {
                in_single_quotes = !in_single_quotes;
                if (in_single_quotes) {
                    quote_state = SINGLE_QUOTE;
                }
                // No cambiar `quote_state` al cerrar comillas simples
            } else {
                if (section[i] == '$' && quote_state != SINGLE_QUOTE && current_token){
                    start_pos[j] = (strlen(current_token));  // Asignar la dirección de i a start_pos
                    j++;
                }
                current_token = add_char_to_token(current_token, section[i]);
            }
            i++;
            continue;
        }

        // Manejo de >> como un token individual
        if (section[i] == '>' && section[i + 1] == '>') {
            if (current_token) {
                expanded_token = strdup(current_token);
                add_token_to_list(info, expanded_token, is_first_token ? CMD : ARG);
                free(expanded_token);
                free(current_token);
                current_token = NULL;
            }
            add_token_to_list(info, ">>", APPEND);
            i++;
            expect_file = 1;
            is_first_token = 0;
        }
        // Manejo de > como token individual
        else if (section[i] == '>' && section[i + 1] != '>') {
            if (current_token) {
                expanded_token = strdup(current_token);
                add_token_to_list(info, expanded_token, is_first_token ? CMD : ARG);
                free(expanded_token);
                free(current_token);
                current_token = NULL;
            }
            add_token_to_list(info, ">", TRUNC);
            expect_file = 1;
            is_first_token = 0;
        }
        // Manejo de < como token individual
        else if (section[i] == '<') {
            if (current_token) {
                expanded_token = strdup(current_token);
                add_token_to_list(info, expanded_token, is_first_token ? CMD : ARG);
                free(expanded_token);
                free(current_token);
                current_token = NULL;
            }
            add_token_to_list(info, "<", INPUT);
            expect_file = 1;
            is_first_token = 0;
        }
        // Manejo de | solo si no estamos dentro de comillas
        else if (section[i] == '|' && !in_single_quotes && !in_double_quotes) {
            if (current_token) {
                expanded_token = strdup(current_token);
                add_token_to_list(info, expanded_token, is_first_token ? CMD : ARG);
                free(expanded_token);
                free(current_token);
                current_token = NULL;
            }
            while (section[i] == '|') {
                add_token_to_list(info, "|", PIPE);
                i++;
                is_first_token = 0;
            }
            continue;
        }
        // Manejo de espacios o tabuladores si no estamos dentro de comillas
        else if (ft_isspace(section[i]) && !in_single_quotes && !in_double_quotes) {
            if (current_token) {
                char *expanded_token = strdup(current_token);
                add_token_to_list(info, expanded_token, is_first_token ? CMD : (expect_file ? FIL : ARG));
                free(expanded_token);
                free(current_token);
                current_token = NULL;
            }
            is_first_token = 0;
            expect_file = 0;
        }
        else {
            if (section[i] == '$' && quote_state != SINGLE_QUOTE && current_token){
                    start_pos[j] = (strlen(current_token));  // Asignar la dirección de i a start_pos
                    j++;
                }
            current_token = add_char_to_token(current_token, section[i]);
        }

        i++;
    }
    print_start_pos(start_pos);
    int z = 0;
while (start_pos[z] != -1) {
    current_token = expand_variable(current_token, start_pos[z]);
    z++;
}
    if (current_token) {
        expanded_token = strdup(current_token) ;
        add_token_to_list(info, expanded_token, is_first_token ? CMD : (expect_file ? FIL : ARG));
        //free(expanded_token);
        //free(current_token);
    }

    print_start_pos(start_pos);
    free(expanded_token);
    free(current_token);
    free(start_pos);
}

*/

void extract_tokens(const char *section, t_general *info) {
    char *current_token = NULL;  // Única variable para construcción de tokens
    int i = 0;
    int is_first_token = 1;      // Indicador de primer token en la sección
    int expect_file = 0;         // Indicador para identificar si el próximo token es un FILE
    int in_single_quotes = 0;    // Controla el estado de las comillas simples
    int in_double_quotes = 0;    // Controla el estado de las comillas dobles
    int *start_pos = NULL;  // Declarar e inicializar start_pos como puntero a NULL
    int size_malloc;
    int k = 0;
    int j = 0;
    int z = 0;
    QuoteState quote_state = NONE; // Inicialización de la variable de estado
    
    
    if(section && count_dollars(section) > 0){
        size_malloc = count_dollars(section);
        start_pos = malloc(size_malloc * sizeof(int)); // Reservar memoria para start_pos
        if (start_pos == NULL) {
            fprintf(stderr, "Error allocating memory\n");
            exit(EXIT_FAILURE);
        }
        for(k = 0; k < size_malloc; k++){
            start_pos[k] = -1; // Inicializar todos los valores en start_pos a -1
        }
    }
    print_start_pos(start_pos);
    while (section[i] != '\0') {
        // Manejo de comillas dobles
        if (section[i] == '\"') {
            if (!in_single_quotes) {
                in_double_quotes = !in_double_quotes;
                if (in_double_quotes) {
                    quote_state = DOUBLE_QUOTE;
                }
            } else {
                current_token = add_char_to_token(current_token, section[i]);
                if(section[i] == '$' && quote_state != SINGLE_QUOTE && current_token){
                    start_pos[j] = (strlen(current_token)-1);  // Asignar la dirección de i a start_pos
                    j++;
                }
                
            }
            i++;
            continue;
        }

        // Manejo de comillas simples
        if (section[i] == '\'') {
            if (!in_double_quotes) {
                in_single_quotes = !in_single_quotes;
                if (in_single_quotes) {
                    quote_state = SINGLE_QUOTE;
                }
            } else {
                current_token = add_char_to_token(current_token, section[i]);
                if(section[i] == '$' && quote_state != SINGLE_QUOTE && current_token){
                    start_pos[j] = (strlen(current_token)-1);  // Asignar la dirección de i a start_pos
                    j++;
                }
                current_token = add_char_to_token(current_token, section[i]);
            }
            i++;
            continue;
        }

        // Manejo de >> como un token individual
        if (section[i] == '>' && section[i + 1] == '>'&& !in_single_quotes && !in_double_quotes) {
            if (current_token) {
                quote_state = NONE;
                add_token_to_list(info, current_token, is_first_token ? CMD : ARG);
                free(current_token);
                current_token = NULL;
                for(k = 0; k < size_malloc; k++){
            start_pos[k] = -1; // Inicializar todos los valores en start_pos a -1
        }
        j=0;
            }
            add_token_to_list(info, ">>", APPEND);
            i++;
            expect_file = 1;
            is_first_token = 0;
        }
        // Manejo de > como token individual
        else if (section[i] == '>' && section[i + 1] != '>'&& !in_single_quotes && !in_double_quotes) {
            if (current_token) {
                add_token_to_list(info, current_token, is_first_token ? CMD : ARG);
                free(current_token);
                current_token = NULL;
                quote_state = NONE;
                for(k = 0; k < size_malloc; k++){
            start_pos[k] = -1; // Inicializar todos los valores en start_pos a -1
        }
        j=0;
            }
            add_token_to_list(info, ">", TRUNC);
            expect_file = 1;
            is_first_token = 0;
        }
        // Manejo de < como token individual
        else if (section[i] == '<'&& !in_single_quotes && !in_double_quotes) {
            if (current_token) {
                add_token_to_list(info, current_token, is_first_token ? CMD : ARG);
                free(current_token);
                current_token = NULL;
                quote_state = NONE;
                for(k = 0; k < size_malloc; k++){
            start_pos[k] = -1; // Inicializar todos los valores en start_pos a -1
        }
        j=0;
            }
            add_token_to_list(info, "<", INPUT);
            expect_file = 1;
            is_first_token = 0;
        }
        // Manejo de | solo si no estamos dentro de comillas
        else if (section[i] == '|' && !in_single_quotes && !in_double_quotes) {
            if (current_token) {
                add_token_to_list(info, current_token, is_first_token ? CMD : ARG);
                free(current_token);
                current_token = NULL;
                quote_state = NONE;
                for(k = 0; k < size_malloc; k++){
            start_pos[k] = -1; // Inicializar todos los valores en start_pos a -1
        }
        j=0;
            }
            while (section[i] == '|') {
                add_token_to_list(info, "|", PIPE);
                i++;
                is_first_token = 0;
            }
            continue;
        }
        // Manejo de espacios o tabuladores si no estamos dentro de comillas
        else if (ft_isspace(section[i]) && !in_single_quotes && !in_double_quotes) {
            if (current_token) {
                print_start_pos(start_pos);
                while(start_pos[z] != -1){
                    current_token = expand_variable(current_token, start_pos[z]);
                    z++;
        }
                add_token_to_list(info, current_token, is_first_token ? CMD : (expect_file ? FIL : ARG));
                quote_state = NONE;
                
                
    
                free(current_token);
                current_token = NULL;
                quote_state = NONE;
                for(k = 0; k < size_malloc; k++){
            start_pos[k] = -1; // Inicializar todos los valores en start_pos a -1
        }
        j=0;
            }
            is_first_token = 0;
            expect_file = 0;
        }
        // Construcción de token actual
        else {
            // Construcción de token tanto dentro como fuera de comillas
            current_token = add_char_to_token(current_token, section[i]);
            if(section[i] == '$' && quote_state != SINGLE_QUOTE && current_token){
                    start_pos[j] = (strlen(current_token)-1);  // Asignar la dirección de i a start_pos
                    j++;
                }
            
            
        }

        i++;
    }

    // Agregar el último token acumulado al final de la sección
    if (current_token) {
        while(start_pos[z] != -1){
            current_token = expand_variable(current_token, start_pos[z]);
            z++;
        }
        add_token_to_list(info, current_token, is_first_token ? CMD : (expect_file ? FIL : ARG));
        quote_state = NONE;
        print_start_pos(start_pos);
        
        free(current_token);
        for(k = 0; k < size_malloc; k++){
            start_pos[k] = -1; // Inicializar todos los valores en start_pos a -1
        }
        j=0;
    }
    free (start_pos);
}


////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////


// Procesa una sección, extrayendo y añadiendo tokens a la lista
void process_section(char *section, t_general *info) {
    if (section) {
        extract_tokens(section, info);
        free(section);
    }
}


// Tokeniza la entrada dividiéndola en secciones y luego en tokens
// Tokeniza la entrada dividiéndola en secciones y luego en tokens
t_token *tokenize_input(t_general *info, char *input) {
    t_quote_state state;
    open_quote(input, &state); // Verifica las comillas antes de tokenizar

    char *start = input;
    const char *section_delimiters = "|\n";

    info->tokens_list = NULL;

    while (*start) {
        char *section = extract_section(&start, section_delimiters);
        if (section) {
            process_section(section, info);
        }
    }

    return info->tokens_list;
}