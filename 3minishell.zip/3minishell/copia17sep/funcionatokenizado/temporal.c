/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   temporal.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: albealva <albealva@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/12 22:04:12 by albealva          #+#    #+#             */
/*   Updated: 2024/09/12 22:11:29 by albealva         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void extract_tokens(const char *section, t_general *info) {
    char *current_token = NULL;  // Única variable para construcción de tokens
    int i = 0;
    int is_first_token = 1;      // Indicador de primer token en la sección
    int expect_file = 0;         // Indicador para identificar si el próximo token es un FILE
    int in_single_quotes = 0;    // Controla el estado de las comillas simples
    int in_double_quotes = 0;    // Controla el estado de las comillas dobles
    QuoteState quote_state = NONE; // Inicialización de la variable de estado

    size_t start_pos = 0;  // Posición inicial que se actualizará dinámicamente

    while (section[i] != '\0') {
        // Manejo de comillas dobles
        if (section[i] == '\"') {
            if (!in_single_quotes) {        
                in_double_quotes = !in_double_quotes;
                if (in_double_quotes) {
                    quote_state = DOUBLE_QUOTE;
                }
                // No cambiar `quote_state` al cerrar comillas dobles
            } else {
                current_token = add_char_to_token(current_token, section[i]);
            }
            i++;
            continue;
        }

        // Manejo de comillas simples
        if (section[i] == '\'') {
            if (!in_double_quotes) {
                in_single_quotes = !in_single_quotes;
                if (in_single_quotes) {
                    quote_state = SINGLE_QUOTE;
                }
                // No cambiar `quote_state` al cerrar comillas simples
            } else {
                current_token = add_char_to_token(current_token, section[i]);
            }
            i++;
            continue;
        }

        // Manejo de >> como un token individual
        if (section[i] == '>' && section[i + 1] == '>') {
            if (current_token) {
                char *expanded_token = (quote_state == SINGLE_QUOTE) ? strdup(current_token) : expand_variable(current_token, start_pos);
                add_token_to_list(info, expanded_token, is_first_token ? CMD : ARG);
                free(expanded_token);
                free(current_token);
                current_token = NULL;
            }
            add_token_to_list(info, ">>", APPEND);
            i++;
            expect_file = 1;
            is_first_token = 0;
        }
        // Manejo de > como token individual
        else if (section[i] == '>' && section[i + 1] != '>') {
            if (current_token) {
                char *expanded_token = (quote_state == SINGLE_QUOTE) ? strdup(current_token) : expand_variable(current_token, start_pos);
                add_token_to_list(info, expanded_token, is_first_token ? CMD : ARG);
                free(expanded_token);
                free(current_token);
                current_token = NULL;
            }
            add_token_to_list(info, ">", TRUNC);
            expect_file = 1;
            is_first_token = 0;
        }
        // Manejo de < como token individual
        else if (section[i] == '<') {
            if (current_token) {
                char *expanded_token = (quote_state == SINGLE_QUOTE) ? strdup(current_token) : expand_variable(current_token, start_pos);
                add_token_to_list(info, expanded_token, is_first_token ? CMD : ARG);
                free(expanded_token);
                free(current_token);
                current_token = NULL;
            }
            add_token_to_list(info, "<", INPUT);
            expect_file = 1;
            is_first_token = 0;
        }
        // Manejo de | solo si no estamos dentro de comillas
        else if (section[i] == '|' && !in_single_quotes && !in_double_quotes) {
            if (current_token) {
                char *expanded_token = (quote_state == SINGLE_QUOTE) ? strdup(current_token) : expand_variable(current_token, start_pos);
                add_token_to_list(info, expanded_token, is_first_token ? CMD : ARG);
                free(expanded_token);
                free(current_token);
                current_token = NULL;
            }
            while (section[i] == '|') {
                add_token_to_list(info, "|", PIPE);
                i++;
                is_first_token = 0;
            }
            continue;
        }
        // Manejo de espacios o tabuladores si no estamos dentro de comillas
        else if (ft_isspace(section[i]) && !in_single_quotes && !in_double_quotes) {
            if (current_token) {
                char *expanded_token = (quote_state == SINGLE_QUOTE) ? strdup(current_token) : expand_variable(current_token, start_pos);
                add_token_to_list(info, expanded_token, is_first_token ? CMD : (expect_file ? FIL : ARG));
                free(expanded_token);
                free(current_token);
                current_token = NULL;
            }
            is_first_token = 0;
            expect_file = 0;
        }
void extract_tokens(const char *section, t_general *info) {
    char *current_token = NULL;  // Única variable para construcción de tokens
    int i = 0;
    int is_first_token = 1;      // Indicador de primer token en la sección
    int expect_file = 0;         // Indicador para identificar si el próximo token es un FILE
    int in_single_quotes = 0;    // Controla el estado de las comillas simples
    int in_double_quotes = 0;    // Controla el estado de las comillas dobles
    QuoteState quote_state = NONE; // Inicialización de la variable de estado

    size_t start_pos = 0;  // Posición inicial que se actualizará dinámicamente

    while (section[i] != '\0') {
        // Manejo de comillas dobles
        if (section[i] == '\"') {
            if (!in_single_quotes) {        
                in_double_quotes = !in_double_quotes;
                if (in_double_quotes) {
                    quote_state = DOUBLE_QUOTE;
                }
                // No cambiar `quote_state` al cerrar comillas dobles
            } else {
                current_token = add_char_to_token(current_token, section[i]);
            }
            i++;
            continue;
        }

        // Manejo de comillas simples
        if (section[i] == '\'') {
            if (!in_double_quotes) {
                in_single_quotes = !in_single_quotes;
                if (in_single_quotes) {
                    quote_state = SINGLE_QUOTE;
                }
                // No cambiar `quote_state` al cerrar comillas simples
            } else {
                current_token = add_char_to_token(current_token, section[i]);
            }
            i++;
            continue;
        }

        // Manejo de >> como un token individual
        if (section[i] == '>' && section[i + 1] == '>') {
            if (current_token) {
                char *expanded_token = (quote_state == SINGLE_QUOTE) ? strdup(current_token) : expand_variable(current_token, start_pos);
                add_token_to_list(info, expanded_token, is_first_token ? CMD : ARG);
                free(expanded_token);
                free(current_token);
                current_token = NULL;
            }
            add_token_to_list(info, ">>", APPEND);
            i++;
            expect_file = 1;
            is_first_token = 0;
        }
        // Manejo de > como token individual
        else if (section[i] == '>' && section[i + 1] != '>') {
            if (current_token) {
                char *expanded_token = (quote_state == SINGLE_QUOTE) ? strdup(current_token) : expand_variable(current_token, start_pos);
                add_token_to_list(info, expanded_token, is_first_token ? CMD : ARG);
                free(expanded_token);
                free(current_token);
                current_token = NULL;
            }
            add_token_to_list(info, ">", TRUNC);
            expect_file = 1;
            is_first_token = 0;
        }
        // Manejo de < como token individual
        else if (section[i] == '<') {
            if (current_token) {
                char *expanded_token = (quote_state == SINGLE_QUOTE) ? strdup(current_token) : expand_variable(current_token, start_pos);
                add_token_to_list(info, expanded_token, is_first_token ? CMD : ARG);
                free(expanded_token);
                free(current_token);
                current_token = NULL;
            }
            add_token_to_list(info, "<", INPUT);
            expect_file = 1;
            is_first_token = 0;
        }
        // Manejo de | solo si no estamos dentro de comillas
        else if (section[i] == '|' && !in_single_quotes && !in_double_quotes) {
            if (current_token) {
                char *expanded_token = (quote_state == SINGLE_QUOTE) ? strdup(current_token) : expand_variable(current_token, start_pos);
                add_token_to_list(info, expanded_token, is_first_token ? CMD : ARG);
                free(expanded_token);
                free(current_token);
                current_token = NULL;
            }
            while (section[i] == '|') {
                add_token_to_list(info, "|", PIPE);
                i++;
                is_first_token = 0;
            }
            continue;
        }
        // Manejo de espacios o tabuladores si no estamos dentro de comillas
        else if (ft_isspace(section[i]) && !in_single_quotes && !in_double_quotes) {
            if (current_token) {
                char *expanded_token = (quote_state == SINGLE_QUOTE) ? strdup(current_token) : expand_variable(current_token, start_pos);
                add_token_to_list(info, expanded_token, is_first_token ? CMD : (expect_file ? FIL : ARG));
                free(expanded_token);
                free(current_token);
                current_token = NULL;
            }
            is_first_token = 0;
            expect_file = 0;
        }
        else if (section[i] == '$' && !in_single_quotes) { // Manejo inmediato de expansión de variable de entorno
    start_pos = strlen(current_token);  // Actualizar la posición inicial con la longitud de current_token, que corresponde a la posición real de $
    if (quote_state == DOUBLE_QUOTE) {
        // Llena el current_token conforme las posiciones manejadas
        char *expanded_token = expand_variable(current_token, start_pos);
        free(current_token); // Liberar memoria del current_token original
        current_token = expanded_token;
    } else {
        current_token = add_char_to_token(current_token, section[i]);
    }
    i++;
}
else {
    // Añadir carácter a current_token
    current_token = add_char_to_token(current_token, section[i]);
}

i++;

    // Manejo final del token si existe
    if (current_token) {
        char *expanded_token = (quote_state == SINGLE_QUOTE) ? strdup(current_token) : expand_variable(current_token, start_pos);
        add_token_to_list(info, expanded_token, is_first_token ? CMD : (expect_file ? FIL : ARG));
        free(expanded_token);
        free(current_token);
    }
}
    }

    // Manejo final del token si existe
    if (current_token) {
        char *expanded_token = (quote_state == SINGLE_QUOTE) ? strdup(current_token) : expand_variable(current_token, start_pos);
        add_token_to_list(info, expanded_token, is_first_token ? CMD : (expect_file ? FIL : ARG));
        free(expanded_token);
        free(current_token);
    }
}