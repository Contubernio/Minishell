/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   token_1.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: albealva <albealva@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/08 18:10:59 by albealva          #+#    #+#             */
/*   Updated: 2024/09/08 18:24:33 by albealva         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"
#include <readline/readline.h>
#include <readline/history.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

const char *get_token_type_name(int type) {
    static const char *token_type_names[] = {
        "EMPTY",  // 0
        "CMD",    // 1
        "ARG",    // 2
        "TRUNC",  // 3
        "APPEND", // 4
        "INPUT",  // 5
        "FIL",    // 6
        "PIPE",   // 7
        "END"     // 8
    };

    if (type >= 0 && type <= 8) {
        return token_type_names[type];
    } else {
        return "UNKNOWN";
    }
}

// Libera la memoria ocupada por la lista de tokens
void free_tokens_list(t_general *info) {
    t_token *current = info->tokens_list;
    t_token *next;

    while (current != NULL) {
        next = current->next;
        free(current->str);
        free(current);
        current = next;
    }
    info->tokens_list = NULL;
    info->number_of_tokens = 0;
}

void quoting_choice(t_quote_state *state, char c, int *index) {
    if (c == '\"') {
        state->dq = !state->dq; // Alterna el estado de las comillas dobles
    } else if (c == '\'') {
        state->sq = !state->sq; // Alterna el estado de las comillas simples
    }
    (*index)++;
}

int open_quote(const char *line) {
    t_quote_state state = {0, 0}; // Inicializa el estado de las comillas
    int index = 0;

    while (line[index]) {
        quoting_choice(&state, line[index], &index);
    }

    // Verifica si quedan comillas abiertas
    if (state.dq || state.sq) {
        fprintf(stderr, "Error: unclosed quotes\n");
        return 1; // Código de error para comillas no cerradas
    }

    return 0; // No hay errores
}




// Tokeniza la entrada dividiéndola en secciones y luego en tokens
t_token *tokenize_input(t_general *info, char *input) {
    open_quote(input); // Verifica las comillas antes de tokenizar

    char *start = input;
    const char *section_delimiters = "|\n";

    (void)section_delimiters;
    (void)start;

    info->tokens_list = NULL;

    

    return info->tokens_list;
}
