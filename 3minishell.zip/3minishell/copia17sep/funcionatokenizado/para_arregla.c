/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   para_arregla.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: albealva <albealva@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/13 12:29:52 by albealva          #+#    #+#             */
/*   Updated: 2024/09/13 14:03:43 by albealva         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void extract_tokens(const char *section, t_general *info) {
    char *current_token = NULL;  // Única variable para construcción de tokens
    int i = 0;
    int is_first_token = 1;      // Indicador de primer token en la sección
    int expect_file = 0;         // Indicador para identificar si el próximo token es un FILE
    int in_single_quotes = 0;    // Controla el estado de las comillas simples
    int in_double_quotes = 0;    // Controla el estado de las comillas dobles
    int *start_pos = NULL;  // Declarar e inicializar start_pos como puntero a NULL
    int size_malloc;
    int j = 0;
    int z = 0;
    QuoteState quote_state = NONE; // Inicialización de la variable de estado
    
    if(section){
        size_malloc = count_dollars(section);
        start_pos = malloc(size_malloc * sizeof(int)); // Reservar memoria para start_pos
        if (start_pos == NULL) {
            fprintf(stderr, "Error allocating memory\n");
            exit(EXIT_FAILURE);
        }
        for(int k = 0; k < size_malloc; k++){
            start_pos[k] = -1; // Inicializar todos los valores en start_pos a -1
        }
    }

    
    while (section[i] != '\0') {
        // Manejo de comillas dobles
        if (section[i] == '\"') {
            if (!in_single_quotes) {
                in_double_quotes = !in_double_quotes;
                if (in_double_quotes) {
                    quote_state = DOUBLE_QUOTE;
                }
            } else {
                if (section[i] == '$' && quote_state != SINGLE_QUOTE && current_token) {
                    start_pos[j] = (strlen(current_token));  // Asignar la dirección de i a start_pos
                    j++;
                }
                current_token = add_char_to_token(current_token, section[i]);
            }
            i++;
            continue;
        }

        // Manejo de comillas simples
        if (section[i] == '\'') {
            if (!in_double_quotes) {
                in_single_quotes = !in_single_quotes;
                if(in_single_quotes){
                    quote_state = SINGLE_QUOTE;
                }
            } else {
                if (section[i] == '$' && quote_state != SINGLE_QUOTE && current_token) {
                    start_pos[j] = (strlen(current_token));  // Asignar la dirección de i a start_pos
                    j++;
                }
                
                current_token = add_char_to_token(current_token, section[i]);
            }
            i++;
            continue;
        }

        // Manejo de >> como un token individual
        if (section[i] == '>' && section[i + 1] == '>' && !in_single_quotes && !in_double_quotes) {
            if (current_token) {
                add_token_to_list(info, current_token, is_first_token ? CMD : ARG);
                free(current_token);
                current_token = NULL;
            }
            add_token_to_list(info, ">>", APPEND);
            i++;
            expect_file = 1;
            is_first_token = 0;
        }
        // Manejo de > como token individual
        else if (section[i] == '>' && section[i + 1] != '>' && !in_single_quotes && !in_double_quotes) {
            if (current_token) {
                add_token_to_list(info, current_token, is_first_token ? CMD : ARG);
                free(current_token);
                current_token = NULL;
            }
            add_token_to_list(info, ">", TRUNC);
            expect_file = 1;
            is_first_token = 0;
        }
        // Manejo de < como token individual
        else if (section[i] == '<' && !in_single_quotes && !in_double_quotes) {
            if (current_token) {
                add_token_to_list(info, current_token, is_first_token ? CMD : ARG);
                free(current_token);
                current_token = NULL;
            }
            add_token_to_list(info, "<", INPUT);
            expect_file = 1;
            is_first_token = 0;
        }
        // Manejo de | solo si no estamos dentro de comillas
        else if (section[i] == '|' && !in_single_quotes && !in_double_quotes) {
            if (current_token) {
                add_token_to_list(info, current_token, is_first_token ? CMD : ARG);
                free(current_token);
                current_token = NULL;
            }
            while (section[i] == '|') {
                add_token_to_list(info, "|", PIPE);
                i++;
                is_first_token = 0;
            }
            continue;
        }
        // Manejo de espacios o tabuladores si no estamos dentro de comillas
        else if (ft_isspace(section[i]) && !in_single_quotes && !in_double_quotes) {
            if (current_token) {
                
                
                add_token_to_list(info, current_token, is_first_token ? CMD : (expect_file ? FIL : ARG));
                print_start_pos(start_pos);
                
                free(current_token);
                //for(int k = 0; k < size_malloc; k++){
                //    start_pos[k] = -1; // Inicializar todos los valores en start_pos a -1
                //    }
                current_token = NULL;
            }
            is_first_token = 0;
            expect_file = 0;
        }
        // Construcción de token actual
        else {
            // Construcción de token tanto dentro como fuera de comillas
            if (section[i] == '$' && quote_state != SINGLE_QUOTE && current_token) {
                    start_pos[j] = (strlen(current_token));  // Asignar la dirección de i a start_pos
                    j++;
                }
            
            current_token = add_char_to_token(current_token, section[i]);
        }

        i++;
    }
      //  if (start_pos[0] != -1)
        
    // Agregar el último token acumulado al final de la sección
    if (current_token) {
      
        
        while(start_pos[z] != -1){
            current_token = expand_variable(current_token, start_pos[z]);
            z++;
        }
        
        //current_token = expand_variable(current_token, start_pos[0]);
        add_token_to_list(info, current_token, is_first_token ? CMD : (expect_file ? FIL : ARG));
        free(current_token);
        //for(int k = 0; k < size_malloc; k++){
                    //start_pos[k] = -1; // Inicializar todos los valores en start_pos a -1
                //    }
    }
    
}