/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   minishell.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: albealva <albealva@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/03 16:21:21 by albealva          #+#    #+#             */
/*   Updated: 2024/09/08 21:28:58 by albealva         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */


#ifndef MINISHELL_H
#define MINISHELL_H

#include <stddef.h>  // Para size_t
#include <stdbool.h> // Para tipo bool
#include <unistd.h>  // Para write, access, F_OK y STDOUT_FILENO
#include <readline/readline.h>
#include <readline/history.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Definición de tipos de tokens
#define EMPTY 0
#define CMD 1
#define ARG 2
#define TRUNC 3
#define APPEND 4
#define INPUT 5
#define FIL 6
#define PIPE 7
#define END 8

# define MAX_VAR_LENGTH 256
// Definición de la estructura de token
typedef struct s_token {
    char            *str;
    int             type;
    int             is_first;   // Campo para indicar si es el primer token
    int             expansion;  // Campo para manejar expansión
    struct s_token  *prev;
    struct s_token  *next;
} t_token;
// Definición de la estructura general
typedef struct s_general {
    t_token *tokens_list;
    int number_of_tokens;
    char **env;                  // Añadido para solucionar el error 'env' no definido
    int exit_code;
} t_general;

typedef struct s_token_flags
{
	int			*previous_redirect;
	int			*first_token;
	t_general	*info;
}	t_token_flags;

typedef struct s_quote_state {
    int dq; // Indica si estamos dentro de comillas dobles
    int sq; // Indica si estamos dentro de comillas simples
} t_quote_state;



const char *get_token_type_name(int type);
void free_tokens_list(t_general *info);
void quoting_choice(t_quote_state *state, char c, int *index);
int open_quote(const char *line);
t_token *tokenize_input(t_general *info, char *input);
char *extract_section(char **start, const char *delimiters);
int ft_isspace(char c);
char *add_char_to_token(char *token, char c);
void add_token_to_list(t_general *info, const char *str, int type);
void extract_tokens(const char *section, t_general *info);
void process_section(char *section, t_general *info);

char *expand_input(const char *input, char **env);


#endif // MINISHELL_H
