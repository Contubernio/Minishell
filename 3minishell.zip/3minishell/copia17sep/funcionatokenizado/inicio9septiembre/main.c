/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: albealva <albealva@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/17 16:26:16 by mgimon-c          #+#    #+#             */
/*   Updated: 2024/09/08 18:30:35 by albealva         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"
#include <readline/readline.h>
#include <readline/history.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>




// Inicializa la estructura general
int init_general(t_general *info, char **env) {
    info->number_of_tokens = 0;
    info->tokens_list = NULL;
    info->env = env;
    return 0;
}

// Controlador de señal para SIGINT (Ctrl+C)
void sigint_handler(int signo) {
    if (signo == SIGINT) {
        write(STDOUT_FILENO, "\n", 1);
    }
}

// Configura los manejadores de señales
void setup_signals(void) {
    signal(SIGINT, sigint_handler); // Manejo de Ctrl+C
}

// Inicializa el historial de comandos
void init_history(const char *history_file) {
    using_history(); // Habilita el uso del historial
    if (access(history_file, F_OK) == 0) {
        read_history(history_file);
    }
}

// Guarda el historial al final del programa
void cleanup(const char *history_file) {
    write_history(history_file);
}

// Maneja comandos especiales como 'print_on' y 'print_off'
void handle_special_commands(const char *input, int *print_mode) {
    if (strcmp(input, "print_on") == 0) {
        *print_mode = 1;
        printf("Print mode enabled\n");
    } else if (strcmp(input, "print_off") == 0) {
        *print_mode = 0;
        printf("Print mode disabled\n");
    }
}

// Maneja la entrada del usuario y añade comandos al historial
void handle_input(t_general *info, char *input, int *print_mode) {
    add_history(input);
    handle_special_commands(input, print_mode);

    // Tokenizar la entrada
    t_token *token_list = tokenize_input(info, input);

    // Verificar si se generaron tokens
    if (token_list == NULL) {
        free(input);
        return;
    }

    // Imprimir tokens si el modo de impresión está habilitado
    if (*print_mode) {
        t_token *current = token_list;
        while (current) {
            printf("Token: %s, Type: %s\n", current->str, get_token_type_name(current->type));
            current = current->next;
        }
        printf("Total tokens: %d\n", info->number_of_tokens);
    }

    // Limpiar la lista de tokens y liberar la entrada
    free_tokens_list(info);
    free(input);
}


int main(int argc, char **argv, char **env) {
    char *input;
    t_general info;
    const char *history_file = ".minishell_history";
    int print_mode = 1;

    (void)argc;
    (void)argv;

    init_general(&info, env);
    setup_signals();
    init_history(history_file);

    while (1) {
        input = readline("mini🐚> ");
        if (!input) {
            printf("\nExit\n");
            break;
        }

        // Verificar comillas no cerradas antes de manejar la entrada
        if (open_quote(input) != 0) {
            //printf("Error: Comillas no cerradas\n");
            //free(input);
            continue; // Esperar la siguiente entrada
        }

        handle_input(&info, input, &print_mode);

        //free(input); // Liberar la memoria de la entrada
    }

    // Descomentar si deseas guardar el historial
    // cleanup(history_file);

    return 0;
}
