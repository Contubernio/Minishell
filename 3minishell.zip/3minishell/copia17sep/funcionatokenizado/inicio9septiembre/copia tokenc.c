/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   copia tokenc.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: albealva <albealva@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/08 20:23:01 by albealva          #+#    #+#             */
/*   Updated: 2024/09/08 21:14:22 by albealva         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   token_1.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: albealva <albealva@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/08 18:10:59 by albealva          #+#    #+#             */
/*   Updated: 2024/09/08 21:13:30 by albealva         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"
#include <readline/readline.h>
#include <readline/history.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

const char *get_token_type_name(int type) {
    static const char *token_type_names[] = {
        "EMPTY",  // 0
        "CMD",    // 1
        "ARG",    // 2
        "TRUNC",  // 3
        "APPEND", // 4
        "INPUT",  // 5
        "FIL",    // 6
        "PIPE",   // 7
        "END"     // 8
    };

    if (type >= 0 && type <= 8) {
        return token_type_names[type];
    } else {
        return "UNKNOWN";
    }
}

// Libera la memoria ocupada por la lista de tokens
void free_tokens_list(t_general *info) {
    t_token *current = info->tokens_list;
    t_token *next;

    while (current != NULL) {
        next = current->next;
        free(current->str);
        free(current);
        current = next;
    }
    info->tokens_list = NULL;
    info->number_of_tokens = 0;
}

void quoting_choice(t_quote_state *state, char c, int *index) {
    if (c == '\"') {
        state->dq = !state->dq; // Alterna el estado de las comillas dobles
    } else if (c == '\'') {
        state->sq = !state->sq; // Alterna el estado de las comillas simples
    }
    (*index)++;
}

int open_quote(const char *line) {
    t_quote_state state = {0, 0}; // Inicializa el estado de las comillas
    int index = 0;

    while (line[index]) {
        quoting_choice(&state, line[index], &index);
    }

    // Verifica si quedan comillas abiertas
    if (state.dq || state.sq) {
        fprintf(stderr, "Error: unclosed quotes\n");
        return 1; // Código de error para comillas no cerradas
    }

    return 0; // No hay errores
}

//////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////


// Extrae una sección del texto de entrada, considerando cada pipe como una sección independiente


char *extract_section(char **start, const char *delimiters) {
    char *end;
    char *section;
    size_t section_length;
    int in_quotes = 0; // Controla el estado de las comillas
    const char *current_delimiters = delimiters;

    // Saltar delimitadores iniciales
    //while (**start && strchr(current_delimiters, **start)) {
        //(*start)++;
    //}
    //(*start)--;
    if (**start) {
        // Caso especial para manejar pipes (`|`) como secciones independientes
        if (**start == '|') {
            // No mover el puntero aún, para procesar la pipe correctamente
            section = malloc(2); // Espacio para la pipe y el terminador nulo
            if (!section) {
                perror("Malloc failed");
                exit(EXIT_FAILURE);
            }
            section[0] = '|';
            section[1] = '\0';

            // Imprime la sección (pipe en este caso)
            printf("Extracted section: '%s'\n", section);

            // Mueve el puntero para saltar la pipe
            (*start)++;

            return section;
        }

        end = *start;
        while (*end && (!strchr(current_delimiters, *end) || in_quotes)) {
            if (*end == '\"') {
                in_quotes = !in_quotes; // Alterna el estado de las comillas
                // Cambia los delimitadores si estamos dentro o fuera de comillas
                current_delimiters = in_quotes ? "\n" : delimiters;
            }
            end++;
        }

        // Calcula la longitud de la sección
        section_length = end - *start;

        // Asigna memoria para la sección
        section = malloc(section_length + 1); // +1 para el terminador nulo
        if (!section) {
            perror("Malloc failed");
            exit(EXIT_FAILURE);
        }

        // Copia la sección actual
        strncpy(section, *start, section_length);
        section[section_length] = '\0'; // Termina la cadena con '\0'

        // Imprime la sección extraída
        printf("Extracted section: '%s'\n", section);

        // Mueve el puntero al final de la sección
        *start = end;

        return section;
    }

    return NULL;
}


// Añade un token a la lista de tokens
void add_token_to_list(t_general *info, const char *str, int type) {
    t_token *new_token = malloc(sizeof(t_token));
    if (!new_token) {
        perror("Malloc failed");
        exit(EXIT_FAILURE);
    }

    new_token->str = strdup(str);
    if (!new_token->str) {
        perror("Strdup failed");
        exit(EXIT_FAILURE);
    }

    new_token->type = type;
    new_token->prev = NULL;
    new_token->next = NULL;

    if (!info->tokens_list) {
        info->tokens_list = new_token;
    } else {
        t_token *last = info->tokens_list;
        while (last->next) {
            last = last->next;
        }
        last->next = new_token;
        new_token->prev = last;
    }

    info->number_of_tokens++;
}

// Función para añadir un carácter a un string
char *add_char_to_token(char *token, char c) {
    size_t len = token ? strlen(token) : 0; // Calcular longitud actual del token
    char *new_token = malloc(len + 2);      // Reservar espacio para nuevo carácter y '\0'
    if (!new_token) {
        // Manejo de error de memoria (opcional)
        return NULL;
    }
    if (token) {
        strcpy(new_token, token);           // Copiar token existente
        free(token);                        // Liberar memoria del token anterior
    }
    new_token[len] = c;                     // Añadir nuevo carácter
    new_token[len + 1] = '\0';              // Terminar el string con '\0'
    return new_token;
}

// Función para verificar si un carácter es un espacio o tabulador
int ft_isspace(char c) {
    return (c == ' ' || c == '\t');
}



char *get_env_value(const char *key) {
    char *value = getenv(key); // Obtiene el valor de la variable de entorno
    return value ? strdup(value) : strdup(""); // Duplica el valor o devuelve "" si no existe
}

// Función para expandir una variable de entorno
char *expand_variable(const char *token) {
    // Verifica si el token empieza con '$'
    if (token[0] == '$') {
        // Desplaza el puntero para saltar el '$'
        const char *var_name = token + 1;

        // Obtiene el valor de la variable de entorno
        char *var_value = get_env_value(var_name);

        // Verifica si el valor obtenido es una cadena vacía
        if (*var_value == '\0') {
            free(var_value); // Libera la memoria alocada
            return strdup(""); // Devuelve una cadena vacía
        }
        
        return var_value; // Devuelve el valor de la variable de entorno
    }
    
    // Si el token no es una variable de entorno, duplica el token y lo devuelve
    return strdup(token);
}



// Extrae y agrega tokens a la lista
void extract_tokens(const char *section, t_general *info) {
    char *current_token = NULL;
    int i = 0;
    int is_first_token = 1; // Indicador de primer token en la sección
    int expect_file = 0;    // Indicador para identificar si el próximo token es un FILE
    int exp = 1;            // Variable EXP inicializada a 1 para liberar tokens
    int in_quotes = 0;      // Controla el estado de las comillas

    while (section[i] != '\0') {
        // Manejo de comillas
        if (section[i] == '\"') {
            in_quotes = !in_quotes; // Alterna el estado de las comillas
            i++;
            continue; // Avanza al siguiente carácter
        }

        // Manejo de >> como un token individual
        if (section[i] == '>' && section[i + 1] == '>') {
            if (current_token) {
                // Expande la variable solo si el primer carácter es $
                char *token_to_add = current_token;
                if (token_to_add[0] == '$') {
                    token_to_add = expand_variable(token_to_add); // Expande variables
                }
                add_token_to_list(info, token_to_add, is_first_token ? CMD : (expect_file ? FIL : ARG));
                if (exp) free(token_to_add);
                
                current_token = NULL;
            }
            add_token_to_list(info, ">>", APPEND);
            i++; // Avanzar un carácter adicional para saltar el segundo '>'
            expect_file = 1; // El próximo token debe ser FILE
            is_first_token = 0;
        }
        // Manejo de > como token individual (después de verificar >>)
        else if (section[i] == '>' && section[i + 1] != '>') {
            if (current_token) {
                // Expande la variable solo si el primer carácter es $
                char *token_to_add = current_token;
                if (token_to_add[0] == '$') {
                    token_to_add = expand_variable(token_to_add); // Expande variables
                }
                add_token_to_list(info, token_to_add, is_first_token ? CMD : (expect_file ? FIL : ARG));
                if (exp) free(token_to_add);
                
                current_token = NULL;
            }
            add_token_to_list(info, ">", TRUNC);
            expect_file = 1; // El próximo token debe ser FILE
            is_first_token = 0;
        }
        // Manejo de < como token individual
        else if (section[i] == '<') {
            if (current_token) {
                // Expande la variable solo si el primer carácter es $
                char *token_to_add = current_token;
                if (token_to_add[0] == '$') {
                    token_to_add = expand_variable(token_to_add); // Expande variables
                }
                add_token_to_list(info, token_to_add, is_first_token ? CMD : (expect_file ? FIL : ARG));
                if (exp) free(token_to_add);
                
                current_token = NULL;
            }
            add_token_to_list(info, "<", INPUT);
            expect_file = 1; // El próximo token debe ser FILE
            is_first_token = 0;
        }
        // Manejo de | como token de tipo PIPE
        else if (section[i] == '|') {
            if (current_token) {
                // Expande la variable solo si el primer carácter es $
                char *token_to_add = current_token;
                if (token_to_add[0] == '$') {
                    token_to_add = expand_variable(token_to_add); // Expande variables
                }
                add_token_to_list(info, token_to_add, is_first_token ? CMD : ARG);
                if (exp) free(token_to_add);
                
                current_token = NULL;
            }
            // Añadir cada | como un token PIPE, incluso si están consecutivos
            while (section[i] == '|') {
                add_token_to_list(info, "|", PIPE);
                i++;
                is_first_token = 0; // Después de una pipe, el siguiente token debería ser CMD o otro PIPE
            }
            continue;
        }
        // Si el carácter actual es un espacio o tabulador y no estamos en comillas
        else if (ft_isspace(section[i]) && !in_quotes) {
            if (current_token) {
                // Expande la variable solo si el primer carácter es $
                char *token_to_add = current_token;
                if (token_to_add[0] == '$') {
                    token_to_add = expand_variable(token_to_add); // Expande variables
                }
                add_token_to_list(info, token_to_add, is_first_token ? CMD : (expect_file ? FIL : ARG));
                if (exp) free(token_to_add);
                
                current_token = NULL;
            }
            is_first_token = 0; // Después de procesar el espacio, no es el primer token
            expect_file = 0;
        }
        // Construcción de token actual
        else {
            current_token = add_char_to_token(current_token, section[i]);
        }

        i++;
    }

    // Añadir el último token si hay alguno
    if (current_token) {
        // Expande la variable solo si el primer carácter es $
        char *token_to_add = current_token;
        if (token_to_add[0] == '$') {
            token_to_add = expand_variable(token_to_add); // Expande variables
        }
        add_token_to_list(info, token_to_add, is_first_token ? CMD : (expect_file ? FIL : ARG));
        if (exp) free(token_to_add);
    }
}






// Procesa una sección, extrayendo y añadiendo tokens a la lista
void process_section(char *section, t_general *info) {
    if (section) {
        extract_tokens(section, info);
        free(section);
    }
}


// Tokeniza la entrada dividiéndola en secciones y luego en tokens
// Tokeniza la entrada dividiéndola en secciones y luego en tokens
t_token *tokenize_input(t_general *info, char *input) {
    open_quote(input); // Verifica las comillas antes de tokenizar

    char *start = input;
    const char *section_delimiters = "|\n";

    info->tokens_list = NULL;

    while (*start) {
        char *section = extract_section(&start, section_delimiters);
        if (section) {
            process_section(section, info);
        }
    }

    return info->tokens_list;
}