/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   cosas.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: albealva <albealva@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/12 20:43:58 by albealva          #+#    #+#             */
/*   Updated: 2024/09/13 14:18:41 by albealva         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void inspect_expand_variable(const char *input, size_t start_pos) {
    printf("Inspecting expand_variable...\n");
    printf("Input: %s\n", input);
    printf("Start position: %zu\n", start_pos);

    // Mostrar el contenido de input a partir de start_pos para asegurar alineación
    for (size_t i = start_pos; i < start_pos + 10; i++) {
        printf("input[%zu]: '%c'\n", i, input[i]);
        fflush(stdout);
    }
}


char *expand_variable(const char *input, size_t start_pos) {
    char *result = NULL;
    size_t len = strlen(input);
    char temp[1024] = {0};  // Buffer temporal para construir el resultado expandido
    size_t temp_index = 0;  // Índice para el buffer temporal
    int expanded = 0;  // Bandera para saber si ya hemos expandido una variable

    // Copiar los caracteres iniciales antes de start_pos
    for (size_t j = 0; j < start_pos; j++) {
        temp[temp_index++] = input[j];
    }

    for (size_t i = start_pos; i < len; i++) {
        // Expandir solo a partir de start_pos y solo una vez
        if (input[i] == '$' && !expanded) {
            char *value = get_env_var("USER");  // Forzado "USER"
            if (value) {
                strcpy(temp + temp_index, value);
                temp_index += strlen(value);
            }
            expanded = 1;  // Marca que ya hemos expandido una variable
        } else {
            // Copiar el contenido literal al buffer temporal
            temp[temp_index++] = input[i];
        }
    }

    // Duplicar el resultado expandido
    result = strdup(temp);
    return result;
}



if (section) {
    size_of_malloc = count_dollar_signs(section);
    start_pos = malloc(sizeof(int) * size_of_malloc);
    if (!start_pos) {
        perror("Malloc failed");
        exit(EXIT_FAILURE);
    }
    for(k = 0; k < size_of_malloc; k++) {
        start_pos[k] = -1;
    }

}