/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   minishell.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: albealva <albealva@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/18 13:34:43 by mgimon-c          #+#    #+#             */
/*   Updated: 2024/08/19 21:04:09 by albealva         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

	#ifndef MINISHELL_H
#define MINISHELL_H

#include "libft/libft.h"
#include <stdio.h>
#include <fcntl.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <sys/wait.h>
#include <readline/readline.h>
#include <readline/history.h>

#define EMPTY 0
#define CMD 1
#define ARG 2
#define TRUNC 3
#define APPEND 4
#define INPUT 5
#define FIL 6
#define PIPE 7
#define END 8

typedef struct s_token {
    char *str;
    int type;
    struct s_token *prev;
    struct s_token *next;
} t_token;

typedef struct s_general {
    int number_of_tokens;
    struct s_token *tokens_list;
    char **env;
    char **paths;
} t_general;

// Prototipos de funciones
void tokenize_input(t_general *info, char *input);
void free_tokens_list(t_general *info);

#endif