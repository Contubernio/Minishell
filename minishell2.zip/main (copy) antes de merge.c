/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mgimon-c <mgimon-c@student.42barcelon      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/17 16:26:16 by mgimon-c          #+#    #+#             */
/*   Updated: 2024/07/29 17:11:09 by albealva         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

void sigint_handler(int signo)
{
    if (signo == SIGINT)
    {
        printf("\n");
        rl_on_new_line();    // Preparar una nueva línea en el terminal
        rl_replace_line("", 0);  // Limpiar la línea en terminal pero no salir
        rl_redisplay();  // Redibujar el prompt para el usuario
    }
    // Agregar para evitar la advertencia por parametro no utilizado cuando no se usa dentro de la función
    (void)signo; 
}

void sigquit_handler(int signo)
{
    if (signo == SIGQUIT)
    {
        printf("Quit: %d\n", signo);  // Mostrar mensaje pero sin finalizar el proceso
    }
    // Igualmente se agrega para evitar la advertencia.
    (void)signo;
}

int init_general(t_general *info, char **env)
{
    // Se asume que esta función inicializa info y puede ser ajustada desde env
    info->number_of_tokens = 0;
    info->tokens_list = NULL;

    // Enviar a silenciar el warning sobre el parámetro env no utilizado mediante void. 
    // Remover este comentario si planeas hacer uso de env.
    (void)env;

    return 0; // Retornar cero indica éxito
}

int main(int argc, char **argv, char **env)
{
    char *input;
    t_general info; // Declaración de la estructura necesaria
    const char *history_file = ".minishell_history";

    // Inicialización, ignorar parámetros argc y argv por ahora
    (void)argc;
    (void)argv;
    (void)env;

    // Activa el uso del historial para Readline y carga un archivo de historial existente
    using_history();
    read_history(history_file);

    // Ajusto el manejo de señales del sistema
    signal(SIGINT, sigint_handler);   // Para evitar la terminación con ctrl+C
    signal(SIGQUIT, sigquit_handler); // Para manejar ctrl+

    while (1)
    {
        input = readline("mini> ");
        if (!input)
        {
            printf("Exit\n");
            break; // Salir en EOF
        }
        
        // Omitir líneas vacías del historial y realizar la inicialización.
        if (init_general(&info, env) == 0 && *input)
        {
            add_history(input); // Agregar entradas al historial si estas no están vacías.
        }

        free(input); // Liberar la entrada después de usarla.
    }

    // Guardar el historial en el archivo al final.
    write_history(history_file);
    return 0;
}
