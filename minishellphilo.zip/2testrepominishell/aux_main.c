/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   aux_main.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: albealva <albealva@student.42barcelona.co  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/28 20:30:12 by albealva          #+#    #+#             */
/*   Updated: 2024/11/28 20:49:23 by albealva         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

int	init_general(t_general *info, char **env)
{
	info->number_of_tokens = 0;
	info->tokens_list = NULL;
	info->env = env;
	return (0);
}

void	init_history(const char *history_file)
{
	using_history();
	if (access(history_file, F_OK) == 0)
	{
		read_history(history_file);
	}
}

void	cleanup(const char *history_file)
{
	write_history(history_file);
}

void	handle_special_commands(const char *input, int *print_mode)
{
	if (strcmp(input, "print_on") == 0)
	{
		*print_mode = 1;
		printf("Print mode enabled\n");
	}
	else if (strcmp(input, "print_off") == 0)
	{
		*print_mode = 0;
		printf("Print mode disabled\n");
	}
}

int	limtit_input(char *input)
{
	if (input != NULL)
	{
		if (ft_strlen(input) > 2890)
		{
			printf("Error: prompt limit exceeded:\n");
			input[2890] = '\0';
			return (1);
		}
	}
	return (0);
}

/*
void	print_tokens_list_alb(t_general *info)
{
	t_token	*current;
	int		i;

	current = info->tokens_list;
	i = 1;
	if (!current)
	{
		printf("La lista de tokens está vacía.\n");
		return ;
	}
	printf("Número de tokens: %d\n", info->number_of_tokens);
	while (current != NULL)
	{
		printf("Token %d:\n", i);
		printf("  - Valor: %s\n", current->str ? current->str : "(null)");
		printf("  - Tipo: %d\n", current->type);
		printf("  - Anterior: %s\n",
			current->prev ? current->prev->str : "(null)");
		printf("  - Siguiente: %s\n\n",
			current->next ? current->next->str : "(null)");
		current = current->next;
		i++;
	}
}*/
