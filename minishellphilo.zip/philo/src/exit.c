/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   exit.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: albealva <albealva@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/10 18:45:30 by albealva          #+#    #+#             */
/*   Updated: 2024/11/11 08:33:52 by albealva         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "include/philosophers.h"

int	ft_exit(t_data *data)
{
	int	i;

	i = -1;
	while (++i < data->num_philos)
	{
		if (i == 0)
		{
			pthread_mutex_destroy(&data->print);
			pthread_mutex_destroy(&data->monitor);
			pthread_mutex_destroy(&data->eat);
		}
		if (&data->fork[i])
			pthread_mutex_destroy(&data->fork[i]);
	}
	if (data->fork)
		free(data->fork);
	if (data->philo)
		free(data->philo);
	return (0);
}
