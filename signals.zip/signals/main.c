/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: albealva <albealva@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/17 16:26:16 by mgimon-c          #+#    #+#             */
/*   Updated: 2024/11/28 21:09:27 by albealva         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

int		g_global_status = 0;

void	ft_print_token(t_token *token_list, t_general *info)
{
	t_token *current;
	current = token_list;
	while (current)
		{
			printf("Token: %s, Type: %s\n", current->str,
				get_token_type_name(current->type));
			current = current->next;
		}
		printf("Total tokens: %d\n", info->number_of_tokens);
}

void	handle_input(t_general *info, char *input, int *print_mode)
{
	char	*new_input;
	t_token	*token_list;

	add_history(input);
	handle_special_commands(input, print_mode);
	if (!input)
		input = "\n";
	while (1)
	{
		new_input = extract_current_section(input, info);
		if (!new_input)
			break ;
		if (strcmp(input, new_input) == 0)
			break ;
		input = new_input;
	}
	token_list = tokenize_input(info, input);
	tokenize_input(info, input);
	if (token_list == NULL)
	{
		input = NULL;
		return ;
	}
	if (*print_mode)
		ft_print_token(token_list, info);
	return ;
}

int	main(int argc, char **argv, char **env)
{
	char			*input;
	t_general		info;
	const char		*history_file = ".minishell_history";
	int				print_mode;
	t_quote_state	state;

	print_mode = 0;
	(void)argc;
	(void)argv;
	g_global_status = 0;
	init_general(&info, env);
	init_history(history_file);
	set_paths_and_env(&info, env);
	while (1)
	{
		setup_signals(0);
		input = readline("mini> ");
		if (g_global_status != 0)
			info.exit_status = g_global_status;
		if (!input)
		{
			matrix_free(info.paths);
			matrix_free(info.exports);
			matrix_free(info.env);
			put_str_fd(2, "exit\n");
			break ;
		}
		if (input && has_content(input) && !limtit_input(input))
		{
			if (open_quote(input, &state) != 0)
			{
				free(input);
				input = NULL;
				continue ;
			}
			handle_input(&info, input, &print_mode);
			if (check_syntax_errors(&info) == 1)
			{
				free(input);
				input = NULL;
				continue ;
			}
			info.sections = create_sections_list(&info);
			executor(&info);
			free_heredocs(&info);
			free_all_allocated_blocks(&info);
			free_sections_list(info.sections);
			free(input);
			input = NULL;
		}
		if (input)
		{
			free(input);
			input = NULL;
		}
		else
		{
			free(input);
			input = NULL;
		}
		if (info.null_paths == 1)
			info.paths = NULL;
	}
	write_history(history_file);
	free(input);
	input = NULL;
	free_all_allocated_blocks(&info);
	return (0);
}
