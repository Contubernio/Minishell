/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   token_div_5.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: albealva <albealva@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/03 16:19:03 by albealva          #+#    #+#             */
/*   Updated: 2024/09/03 19:20:15 by albealva         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

void	handle_plain_text(char **rest, t_general *inf, t_token_flags *flg)
{
	char	*token_start;
	size_t	length;

	token_start = *rest;
	while (**rest && **rest != ' ' && **rest != '"' && **rest != '\'')
		(*rest)++;
	length = *rest - token_start;
	if (length > 0)
		process_token(token_start, rest, inf, flg);
}

void	tokenize_input(t_general *info, char *input)
{
	char			*rest;
	char			*incomplete_token;
	int				previous_redirect;
	int				first_token;
	t_token_flags	flags;

	rest = input;
	incomplete_token = NULL;
	previous_redirect = 0;
	first_token = 1;
	flags.previous_redirect = &previous_redirect;
	flags.first_token = &first_token;
	flags.info = info;
	info->number_of_tokens = 0;
	info->tokens_list = NULL;
	while (*rest)
	{
		p_tok(&rest, info, &flags, &incomplete_token);
		if (incomplete_token)
		{
			process_incomplete_token_content(incomplete_token, info);
			free(incomplete_token);
			break ;
		}
	}
}

t_token *reverse_copy_list(t_token *tokens_list)
{
    t_token *reversed_list = NULL;
    t_token *current = tokens_list;
    t_token *new_node = NULL;

    while (current)
    {
        new_node = create_node(current->str, current->type);
        if (!new_node)
        {
            while (reversed_list)
            {
                t_token *temp = reversed_list;
                reversed_list = reversed_list->next;
                free(temp->str);
                free(temp);
            }
            return NULL;
        }

        new_node->next = reversed_list;
        if (reversed_list)
            reversed_list->prev = new_node;
        reversed_list = new_node;

        current = current->next;
    }

    return (reversed_list);
}
t_token *create_node(char *str, int type)
{
    t_token *new_node = (t_token *)malloc(sizeof(t_token));
    if (!new_node)
        return NULL;

    new_node->str = ft_strdup(str);
    new_node->type = type;
    new_node->prev = NULL;
    new_node->next = NULL;

    return new_node;
}

