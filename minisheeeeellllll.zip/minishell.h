/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   minishell.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mgimon-c <mgimon-c@student.42barcelon      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/18 13:34:43 by mgimon-c          #+#    #+#             */
/*   Updated: 2024/09/03 19:22:28 by albealva         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef MINISHELL_H
# define MINISHELL_H

# include "libft/libft.h"
# include <stdio.h>
# include <fcntl.h>
# include <stdlib.h>
# include <limits.h>
# include <unistd.h>
# include <signal.h>
# include <sys/wait.h>
# include <sys/stat.h>
# include <readline/readline.h>
# include <readline/history.h>

# define EMPTY 0
# define CMD 1
# define ARG 2
# define TRUNC 3
# define APPEND 4
# define INPUT 5
# define FIL 6
# define PIPE 7
# define END 8

typedef struct	s_token
{
	char			*str;
	int				type;
	struct s_token	*prev;
	struct s_token	*next;
}	t_token;

typedef struct	s_file
{
	struct s_file	*next;
	char			*string;
	int				open_mode;
}	t_file;

typedef struct	s_section
{
	int					gottofree;
	struct s_general	*info;
	struct s_section	*next;
	t_file				*files;
	int					fd_read;
	int					fd_write;
	char				**env;
	char				**paths;
	char				*path;
	char				**cmdv;
}	t_section;

typedef	struct	s_general
{
	int					exit_status;
	int					number_of_tokens;
	struct s_token		*tokens_list;
	char				**env;
	char				**exports;
	char				**paths;
	struct s_section	*sections;
}	t_general;

typedef struct s_token_flags
{
	int			*previous_redirect;
	int			*first_token;
	t_general	*info;
}	t_token_flags;



// tokens.c
t_token	*reverse_copy_list(t_token *tokens_list);
void	tokenize_input(t_general *info, char *input);
t_token *create_node(char *str, int type);

//tokens_div
void	handle_malloc_failure(void);
void	create_and_store_token(char *token_start, char *rest, t_general *info);
void	process_incomplete_token(char *token, t_general *info);
void	free_tokens_list2(t_general *info);
void	skipespace(char **rest);
void	tokenize_input(t_general *info, char *input);
void	process_quoted_token(char quote, char **rest,
			t_general *info, int *first_token);
void	process_plain_token(char **rest, t_general *info,
			int *first_token, int *previous_redirect);
void	create_and_add_token(char *inner_token, t_general *info,
			int *first_token, int *previous_redirect);
void	initialize_first_half(char **rest, int *first_token,
			char **incomplete_token);
void	initialize_second_half(t_general *info,
			int *previous_redirect, char *quote);
void	handle_incomplete_token(char *token_start,
			char **rest, char **incomplete_token);
void	handle_quotes_and_process(char **rest,
			t_token_flags *flg, char **inco_tok);
void	handle_plain_text(char **rest, t_general *inf, t_token_flags *flg);
void	p_tok(char **rest, t_general *inf, t_token_flags *flg, char **inco_tok);
void	process_token(char *token_start, char **rest,
			t_general *info, t_token_flags *flags);
void	process_incomplete_token_content(char *incomplete_token,
			t_general *info);
void	set_flags(int *previous_redirect, int *first_token,
			const t_token *token);
void	classify_token_type(t_token *token, char *inner_token,
			int *previous_redirect, int *first_token);
void	insert_token_to_list(t_general *info, t_token *new_token);
t_token	*create_new_token(char *inner_token);
int		is_redirection(const char *token_str);
int		is_pipe_or_end(const char *token_str);
void	update_token_type(t_token *token, const char *token_str);
void	p_tok(char **rest, t_general *inf, t_token_flags *flg, char **inco_tok);

// sections.c
t_section	*create_sections_list(t_general *info);

// executor.c
void	executor(t_general *info);

// prints.c
void	put_str_fd(int fd, char *str);
void    print_tokens_list(t_token *tokens_list);
void    print_matrix(char **matrix);
void    print_string_to_stderror(char *str);
void    print_sections_info(t_section *section);

// frees.c
void	matrix_free(char **str);
void	free_sections_list(t_section *first);
void    free_tokens_list(t_token *first);

// utils_1.c
int		thereis_pipe(t_token *first);
void    set_paths_and_env(t_general *info, char **env);
int		count_tokens_per_section(t_token *first);
int		count_sections(t_token *first);
int		ft_strncmp_pipex(const char *str, const char *str2, size_t c);

// utils_2.c
int		count_files_per_section(t_token *first);
int		count_cmdvs_per_section(t_token *first);
t_token *get_first_in_section(t_token *first, int s);
void    add_file_to_files(t_token *section_first, t_file *files, int *i, int n);
void    open_files_section(t_section *section);

// utils_3.c
int		exec_if_builtin_1(t_section *current);
void	exec_if_builtin_2(t_section *current);
char    *ft_strjoin_pipex(char const *s1, char const *s2);
void	set_cmd_in_paths(t_section *section);
void	set_path(t_section *section);

// utils_4.c
char    *add_var_equal(char *cmdv1);
char    **remove_env_line(t_section *current, int line);
int		is_directory(const char *path);
char	*ft_getenv(const char *name, char **env);
void	set_exports(t_general *info, char **env);

// utils_5.c
void	add_str_to_matrix(char ***matrix, char *str);
void	fill_expanded_string(const char *src, char *dest, char **env);
int		calculate_new_length(const char *str, char **env);
char	*clean_str_exit(char *str);

// builtins_1.c
int		execute_echo(t_section *current);
int		execute_pwd(t_section *current);
int		execute_env(t_section *current);

// builtins_2.c
void	execute_unset(t_section *current);
void	execute_export(t_section *current);
void    execute_cd(t_section *current);
void	execute_exit(t_section *current);

#endif
